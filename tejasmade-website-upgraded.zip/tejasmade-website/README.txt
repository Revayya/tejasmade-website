================================================================================
TEJASMADE WEBSITE & ADMIN CONTROL PANEL
Customized Gifts, Apparel, Corporate Merchandise & Store CMS
================================================================================

Overview
--------------------------------------------------------------------------------
This is the upgraded build of the official TEJASMADE e-commerce website,
extended with a full-featured, professional Admin Control Panel (CMS).

The original TEJASMADE brand identity, color scheme (cream, ink, forest green,
and gold), typography (DM Sans and Manrope), product catalog, shopping cart,
and WhatsApp order flow have all been carefully preserved and dynamically
integrated with the new control panel.


Technology Stack
--------------------------------------------------------------------------------
- HTML5 (semantic markup, accessibility, responsive metadata)
- CSS3 (custom CSS variables, flexbox, CSS grid, smooth animations)
- Vanilla JavaScript (modern ES6+, zero external frameworks or node dependencies)
- LocalStorage (structured JSON storage for products, categories, posters, settings)
- IndexedDB ("TejasMadeImageStore_v1" for large-capacity, permanent image storage)
- Browser File API (file uploads, image preview, image optimization)


Project File Structure
--------------------------------------------------------------------------------
tejasmade-website/
│
├── index.html                  # Public storefront (hero slider, categories, dynamic products)
├── cart.html                   # Shopping cart & WhatsApp checkout enquiry
├── admin-login.html            # Protected admin login interface with show/hide password
├── admin.html                  # Admin Dashboard (KPI metrics, recent updates, quick actions)
├── admin-products.html         # Product Management (add, edit, delete, upload image, pricing)
├── admin-posters.html          # Poster Management (hero banners, promotional offers, slides)
├── admin-categories.html       # Category Management (categories, images, icons, ordering)
├── admin-settings.html         # Store Settings (logo, WhatsApp number, copy, credentials, backup)
│
├── css/
│   ├── style.css               # Storefront & cart styling with brand palette
│   └── admin.css               # Professional CMS dashboard styling
│
├── js/
│   ├── storage.js              # Central persistence layer (LocalStorage + IndexedDB engine)
│   ├── admin-auth.js           # Session authentication, login/logout, page route protection
│   ├── admin-common.js         # Shared admin UI components (toasts, confirm modals, drawer)
│   ├── admin-dashboard.js      # Dashboard KPI cards and activity controller
│   ├── admin-products.js       # Product catalogue CRUD controller & image processor
│   ├── admin-posters.js        # Promotional poster/banner controller
│   ├── admin-categories.js     # Category management controller
│   ├── admin-settings.js       # Website settings & JSON backup import/export
│   └── script.js               # Dynamic storefront controller & WhatsApp order generator
│
├── assets/
│   ├── tejasmade-logo.png      # TEJASMADE brand logo
│   ├── TejasMadeLogo.png       # High-resolution original logo asset
│   └── images/                 # Local image directory for assets
│
├── README.txt                  # Documentation & setup instructions (this file)
└── README.md                   # Formatted Markdown documentation


Admin Login Instructions
--------------------------------------------------------------------------------
1. To access the Admin Panel, navigate to:
   admin-login.html (or click the "Admin Panel 🔒" link in the storefront footer)

2. Pre-configured Demo Credentials:
   - Username: admin
   - Password: tejasmade123

3. Features on the Login Page:
   - "Auto-fill Demo Credentials" one-click button for quick testing
   - Password show/hide toggle button
   - "Remember me on this device" option
   - Session protection: All admin pages (admin.html, admin-products.html, etc.)
     automatically check for an active login session. Direct unauthorized
     navigation is intercepted and redirected to the login page.
   - Credentials can be changed anytime in Website Settings -> Admin Security.


Key Features & Functionality
--------------------------------------------------------------------------------
1. Product Management:
   - Add new products with custom or auto-generated product IDs.
   - Edit existing products in real-time.
   - Delete products with safe confirmation modal dialog.
   - Upload high-resolution images from computer (JPG, JPEG, PNG, WEBP).
   - Live image preview before saving with change/remove controls.
   - Dynamic category selection dropdown.
   - Dual pricing mode: "Enquiry Only (Price on WhatsApp)" or "Display Fixed Price".
   - Visibility toggle switch (instant activate/deactivate without opening modal).
   - Instant search by title, ID, or description and filter by category/status.

2. Promotional Poster & Banner Management:
   - Upload promotional campaign banners from computer.
   - Add title, subtitle, promotional offer badge (e.g. "20% Off", "Trending").
   - Configure button text and destination link (#products, WhatsApp, etc.).
   - Set numeric display order.
   - Active/Inactive toggle for each poster.
   - The storefront homepage automatically renders active posters in the
     responsive hero carousel with 5-second auto-rotation and manual controls.

3. Category Management:
   - Add, edit, and delete product categories.
   - Upload category card images from computer.
   - Configure category icon/symbol, slug, and display order.
   - Public website categories section and product filter buttons update automatically.

4. Website Settings:
   - Update website logo (upload computer image).
   - Change WhatsApp order contact number (receives all checkout enquiries).
   - Edit announcement bar text.
   - Edit homepage hero headline, description, and trust notes.
   - Update support email, Instagram profile URL, and handle.
   - Update footer copyright notice.

5. Data Backup & Recovery:
   - One-click JSON backup export (includes all products, posters, categories,
     settings, and IndexedDB images in a single downloadable file).
   - Restore from backup file anytime.
   - "Reset to Factory Demo Data" button to restore default demo catalog.

6. Shopping Cart & WhatsApp Checkout:
   - Retains existing shopping cart functionality with live cart badge counter.
   - Cart items persist across page views.
   - Quantity controls (+, -) and item removal.
   - Checkout generates a clean, structured WhatsApp order enquiry containing
     the customer name, city, item list (with quantities and prices), and notes,
     routed directly to the configured WhatsApp number.


LocalStorage and IndexedDB Architecture & Limitations
--------------------------------------------------------------------------------
1. Why Both LocalStorage and IndexedDB are Used:
   - LocalStorage is synchronous, extremely fast, and universally supported,
     making it ideal for structured JSON metadata (product lists, categories,
     posters, settings, and cart state).
   - However, LocalStorage has a strict quota limit (~5MB per origin in most
     browsers). Storing multiple high-resolution Base64 images directly inside
     LocalStorage would quickly exceed the quota and trigger QuotaExceededError.
   - To overcome this, our hybrid storage architecture (in js/storage.js) uses
     IndexedDB ("TejasMadeImageStore_v1") to store uploaded image data.
     IndexedDB typically supports hundreds of megabytes of storage per origin.
   - In addition, an off-screen HTML5 Canvas downscales uploaded images to
     optimal web dimensions (e.g. max 1920px) before storage, ensuring lightning-
     fast load times while maintaining crisp visual fidelity.

2. Browser-Side Persistence Considerations:
   - Browser Storage is scoped to the specific browser and domain/origin.
     Changes made in Chrome will not automatically appear in Firefox or on another
     computer unless exported and imported via the Backup tool.
   - Clearing browser site data or cache will erase stored data unless a backup
     has been downloaded.
   - Private/Incognito Mode creates a temporary session store that is cleared
     when the private window is closed.

3. Production Recommendation:
   - For a production deployment with multiple administrators, customer accounts,
     and cross-device inventory, a server-side backend (such as Node.js, Python,
     or PHP with a MySQL/PostgreSQL database) with secure HTTPS session cookies
     should replace browser-only storage and frontend authentication.


How to Run the Website
--------------------------------------------------------------------------------
Option 1: Open Directly in Browser
- Simply double-click `index.html` to view the public website.
- Open `admin-login.html` to access the Admin Control Panel.

Option 2: Local Web Server (Recommended for File API & IndexedDB)
- Using Python:
    python -m http.server 8000
  Then visit: http://localhost:8000
- Using VS Code Live Server:
  Right-click `index.html` -> "Open with Live Server".


Testing Checklist
--------------------------------------------------------------------------------
[x] 1. Admin login works with demo credentials (admin / tejasmade123).
[x] 2. Admin logout clears session and redirects to login page.
[x] 3. Protected admin pages redirect to login if session is missing.
[x] 4. Add new product with image, category, and pricing.
[x] 5. Edit existing product and verify changes reflect on storefront.
[x] 6. Delete product with confirmation modal.
[x] 7. Upload product image from computer and preview before saving.
[x] 8. Add promotional poster and verify appearance in homepage hero carousel.
[x] 9. Edit/delete promotional posters.
[x] 10. Add, edit and delete categories; check storefront filter buttons.
[x] 11. Update WhatsApp phone number and test checkout order link.
[x] 12. Add products to cart, change quantities, and remove items.
[x] 13. Verify WhatsApp order message formatting and parameters.
[x] 14. Refresh page and verify all data persists in LocalStorage & IndexedDB.
[x] 15. Responsive layout tested across desktop and mobile screen sizes.

================================================================================
TEJASMADE — Custom Made. Just for You.
================================================================================
