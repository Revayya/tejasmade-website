/**
 * TEJASMADE — Storefront & Cart Integration Script
 * Dynamically connected to Central StorageService (LocalStorage + IndexedDB)
 */

const CART_KEY = "tejasmade_html_cart_v1";

// ---------------- CART MANAGEMENT ----------------
const getCart = () => {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
  } catch (e) {
    return [];
  }
};

const setCart = (cart) => {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
  renderCart();
};

const esc = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#039;"
}[c]));

function updateCartCount() {
  const el = document.getElementById("cart-count");
  if (el) {
    el.textContent = getCart().reduce((sum, item) => sum + Number(item.qty || 1), 0);
  }
}

function addToCart(id) {
  const product = window.StorageService ? window.StorageService.getProductById(id) : null;
  if (!product) return;

  const cart = getCart();
  const existing = cart.find(item => item.id === id);

  if (existing) {
    existing.qty = Math.min(999, (existing.qty || 1) + 1);
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      category: product.label || product.category,
      price: product.price || "",
      qty: 1
    });
  }

  setCart(cart);

  const feedback = document.getElementById("shop-feedback");
  if (feedback) feedback.textContent = product.name + " added to cart.";
}

// ---------------- STOREFRONT DYNAMIC RENDERING ----------------
let currentCategoryFilter = "all";

function applyStoreSettings() {
  if (!window.StorageService) return;
  const settings = StorageService.getSettings();

  // Announcement Bar
  const announcementEl = document.querySelector(".announcement");
  if (announcementEl && settings.announcement) {
    announcementEl.textContent = settings.announcement;
  }

  // Brand Logos
  const brandLogos = document.querySelectorAll(".brand-logo, .footer-brand img");
  if (settings.logoUrl) {
    StorageService.resolveImageSource(settings.logoUrl).then(resolved => {
      brandLogos.forEach(img => { if (resolved) img.src = resolved; });
    });
  }

  // Hero Section
  const eyebrowEl = document.querySelector(".hero-copy .eyebrow");
  if (eyebrowEl && settings.heroEyebrow) eyebrowEl.textContent = settings.heroEyebrow;

  const heroHeadingEl = document.querySelector(".hero-copy h1");
  if (heroHeadingEl && settings.heroTitle) heroHeadingEl.innerHTML = settings.heroTitle;

  const heroDescEl = document.querySelector(".hero-copy > p:not(.eyebrow)");
  if (heroDescEl && settings.heroSubtitle) heroDescEl.textContent = settings.heroSubtitle;

  const heroNoteEl = document.querySelector(".hero-note");
  if (heroNoteEl && settings.heroNote) heroNoteEl.innerHTML = settings.heroNote;

  // Contact section WhatsApp links and details
  const whatsappNum = settings.whatsappNumber || "919606799579";
  const whatsappButtons = document.querySelectorAll("a[href*='wa.me']");
  whatsappButtons.forEach(btn => {
    const currentHref = btn.getAttribute("href");
    if (currentHref) {
      btn.href = currentHref.replace(/wa\.me\/\d+/, `wa.me/${whatsappNum}`);
    }
  });

  const contactWhatsappLink = document.querySelector(".contact-actions a[href*='wa.me']");
  if (contactWhatsappLink) {
    contactWhatsappLink.textContent = `WhatsApp: ${whatsappNum}`;
    contactWhatsappLink.href = `https://wa.me/${whatsappNum}?text=Hello%20TEJASMADE%2C%20I%20have%20an%20enquiry.`;
  }

  const emailLink = document.querySelector(".contact-actions a[href^='mailto:']");
  if (emailLink && settings.email) {
    emailLink.href = `mailto:${settings.email}`;
    emailLink.textContent = settings.email;
  }

  const instaLink = document.querySelector(".contact-actions a[href*='instagram.com']");
  if (instaLink && settings.instagramUrl) {
    instaLink.href = settings.instagramUrl;
    if (settings.instagramHandle) instaLink.textContent = `${settings.instagramHandle} on Instagram`;
  }

  // Footer Copyright Text
  const footerSpan = document.querySelector(".site-footer > span");
  if (footerSpan && settings.footerText) {
    const year = new Date().getFullYear();
    footerSpan.innerHTML = `© <span id="year">${year}</span> ${esc(settings.footerText)}`;
  }
}

function renderCategories() {
  if (!window.StorageService) return;
  const grid = document.querySelector(".category-grid");
  const filterRow = document.querySelector(".filter-row");
  const categories = StorageService.getActiveCategories();

  // Render Category Cards Grid
  if (grid && categories.length) {
    grid.innerHTML = categories.map(cat => `
      <a class="category-card ${esc(cat.badgeColor || 'cat-apparel')}" href="#products" data-filter="${esc(cat.slug || cat.id)}">
        <img data-img-src="${esc(cat.image || '')}" alt="${esc(cat.name)}" loading="lazy">
        <span class="category-icon">${esc(cat.icon || '✦')}</span>
        <strong>${esc(cat.name)}</strong>
        <small>${esc(cat.subtitle || 'Customized for you')}</small>
      </a>
    `).join("");
    StorageService.hydrateDynamicImages(grid);
  }

  // Render Filter Buttons Row
  if (filterRow && categories.length) {
    const allBtn = `<button class="filter-button ${currentCategoryFilter === 'all' ? 'active' : ''}" data-filter="all">All products</button>`;
    const catBtns = categories.map(cat => `
      <button class="filter-button ${currentCategoryFilter === (cat.slug || cat.id) ? 'active' : ''}" data-filter="${esc(cat.slug || cat.id)}">
        ${esc(cat.label || cat.name)}
      </button>
    `).join("");
    filterRow.innerHTML = allBtn + catBtns;
  }
}

function renderProducts(filter = "all") {
  currentCategoryFilter = filter;
  const grid = document.getElementById("product-grid");
  if (!grid || !window.StorageService) return;

  const visible = StorageService.getActiveProducts(filter);

  if (!visible.length) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 48px 16px; background: #fff; border-radius: 8px; border: 1px solid #eeece5;">
        <p style="font-size: 15px; font-weight: 600; margin: 0 0 6px;">No products found in this category.</p>
        <p style="font-size: 13px; color: var(--muted); margin: 0 0 16px;">We can still craft custom items tailored to your specific ideas.</p>
        <a href="#contact" class="button button-dark">Request Custom Order</a>
      </div>
    `;
    return;
  }

  grid.innerHTML = visible.map(p => {
    const isEnquiry = !p.price || p.pricingType === "enquiry";
    const priceHtml = isEnquiry 
      ? '<span class="product-price-enquiry">Price shared on WhatsApp</span>' 
      : `<span class="product-price">${esc(p.price)}</span>`;

    const imgTag = p.image
      ? `<img data-img-src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" decoding="async">`
      : `<span class="product-placeholder" aria-hidden="true">${esc(p.icon || '📦')}</span>`;

    return `
      <article class="product-card">
        <div class="product-photo">
          ${imgTag}
        </div>
        <div class="product-details">
          <span class="product-category">${esc(p.label || p.category)}</span>
          <h3>${esc(p.name)}</h3>
          <p>${esc(p.description || '')}</p>
          <div class="product-pricing-row">${priceHtml}</div>
          <button class="button button-dark add-product" data-id="${esc(p.id)}">Add to Cart</button>
        </div>
      </article>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(grid);
}

// ---------------- HERO POSTER CAROUSEL ----------------
let heroSlideIndex = 0;
let heroSlideTimer = null;

function renderHeroBanners() {
  if (!window.StorageService) return;
  const slidesContainer = document.getElementById("hero-slides");
  const dotsContainer = document.querySelector(".hero-dots");
  if (!slidesContainer) return;

  const posters = StorageService.getActivePosters();
  if (!posters.length) return;

  slidesContainer.innerHTML = posters.map((poster, index) => `
    <div class="hero-slide ${index === 0 ? 'active' : ''}" data-bg-src="${esc(poster.image || '')}">
      <div class="hero-slide-content">
        ${poster.offerBadge ? `<span class="hero-poster-badge">${esc(poster.offerBadge)}</span>` : ''}
        <span>${esc(poster.title)}</span>
        ${poster.subtitle ? `<p class="hero-poster-sub">${esc(poster.subtitle)}</p>` : ''}
        ${poster.buttonText ? `<a href="${esc(poster.buttonLink || '#products')}" class="hero-poster-btn">${esc(poster.buttonText)} →</a>` : ''}
      </div>
    </div>
  `).join("");

  if (dotsContainer) {
    dotsContainer.innerHTML = posters.map((_, index) => `
      <button class="${index === 0 ? 'active' : ''}" aria-label="Show slide ${index + 1}"></button>
    `).join("");
  }

  StorageService.hydrateDynamicImages(slidesContainer);
  showHeroSlide(0);
  startHeroSlideshow();
}

function showHeroSlide(index) {
  const slides = [...document.querySelectorAll(".hero-slide")];
  const dots = [...document.querySelectorAll(".hero-dots button")];
  if (!slides.length) return;

  heroSlideIndex = (index + slides.length) % slides.length;
  slides.forEach((slide, i) => slide.classList.toggle("active", i === heroSlideIndex));
  dots.forEach((dot, i) => dot.classList.toggle("active", i === heroSlideIndex));
}

function startHeroSlideshow() {
  if (heroSlideTimer) clearInterval(heroSlideTimer);
  heroSlideTimer = setInterval(() => showHeroSlide(heroSlideIndex + 1), 5000);
}

// ---------------- CART PAGE RENDERING ----------------
function renderCart() {
  const root = document.getElementById("cart-items");
  if (!root) return;
  const cart = getCart();

  if (!cart.length) {
    root.innerHTML = '<div class="cart-empty">Your cart is empty. <a href="index.html#products">Browse products</a> and add the items you are interested in.</div>';
    return;
  }

  root.innerHTML = cart.map((item, index) => {
    const priceText = item.price ? ` · ${esc(item.price)}` : " · Price shared on WhatsApp";
    return `
      <div class="cart-row">
        <div>
          <strong>${esc(item.name)}</strong>
          <small>${esc(item.category || "Customized product")}${priceText}</small>
        </div>
        <div class="quantity-controls">
          <button type="button" data-action="minus" data-index="${index}" aria-label="Decrease quantity">−</button>
          <span>${Number(item.qty || 1)}</span>
          <button type="button" data-action="plus" data-index="${index}" aria-label="Increase quantity">+</button>
        </div>
        <button class="remove-button" type="button" data-action="remove" data-index="${index}">Remove</button>
      </div>
    `;
  }).join("");
}

function sendWhatsAppOrder() {
  const feedback = document.getElementById("cart-feedback");
  const cart = getCart();

  if (!cart.length) {
    if (feedback) feedback.textContent = "Your cart is empty. Please add products first.";
    return;
  }

  const nameInput = document.getElementById("customer-name");
  const cityInput = document.getElementById("customer-city");
  const notesInput = document.getElementById("customer-notes");

  const name = nameInput ? nameInput.value.trim() : "";
  const city = cityInput ? cityInput.value.trim() : "";
  const notes = notesInput ? notesInput.value.trim() : "";

  if (!name) {
    if (feedback) feedback.textContent = "Please enter your name.";
    if (nameInput) nameInput.focus();
    return;
  }

  const settings = window.StorageService ? StorageService.getSettings() : {};
  const whatsappNum = settings.whatsappNumber || "919606799579";

  const lines = [
    "Hello TEJASMADE! I would like to place an order enquiry.",
    "",
    "Customer Name: " + name,
    "City / Delivery Location: " + (city || "Not provided"),
    "",
    "Selected Products:"
  ];

  cart.forEach((item, index) => {
    const priceSuffix = item.price ? ` (${item.price})` : "";
    lines.push(`${index + 1}. ${item.name}${priceSuffix} — Quantity: ${item.qty || 1}`);
  });

  lines.push(
    "",
    "Customization & Design Notes: " + (notes || "Standard order"),
    "",
    "Please confirm available customization, prices, preview mockup and delivery charges. Thank you!"
  );

  const url = `https://wa.me/${whatsappNum}?text=${encodeURIComponent(lines.join("\n"))}`;
  window.open(url, "_blank", "noopener");

  if (feedback) {
    feedback.textContent = "WhatsApp has opened with your order enquiry. Click Send in WhatsApp to submit it to TEJASMADE.";
  }
}

// ---------------- EVENT LISTENERS ----------------
document.addEventListener("click", event => {
  // Add to cart click
  const add = event.target.closest(".add-product");
  if (add) {
    addToCart(add.dataset.id);
    add.textContent = "Added ✓";
    setTimeout(() => { add.textContent = "Add to Cart"; }, 1200);
    return;
  }

  // Category filter click
  const filter = event.target.closest("[data-filter]");
  if (filter) {
    const value = filter.dataset.filter;
    document.querySelectorAll(".filter-button").forEach(b => {
      b.classList.toggle("active", b.dataset.filter === value);
    });
    renderProducts(value);
  }

  // Cart quantity / remove actions
  const action = event.target.closest("[data-action]");
  if (action) {
    const cart = getCart();
    const index = Number(action.dataset.index);
    const item = cart[index];
    if (!item) return;

    if (action.dataset.action === "plus") item.qty = Math.min(999, (item.qty || 1) + 1);
    if (action.dataset.action === "minus") item.qty = Math.max(1, (item.qty || 1) - 1);
    if (action.dataset.action === "remove") cart.splice(index, 1);

    setCart(cart);
  }

  // WhatsApp Checkout button
  if (event.target.closest("#whatsapp-order")) {
    sendWhatsAppOrder();
  }

  // Hero controls
  if (event.target.closest(".hero-next")) {
    showHeroSlide(heroSlideIndex + 1);
    startHeroSlideshow();
  }
  if (event.target.closest(".hero-prev")) {
    showHeroSlide(heroSlideIndex - 1);
    startHeroSlideshow();
  }
  const dot = event.target.closest(".hero-dots button");
  if (dot) {
    const dots = [...document.querySelectorAll(".hero-dots button")];
    showHeroSlide(dots.indexOf(dot));
    startHeroSlideshow();
  }
});

// ---------------- INITIALIZATION ----------------
document.addEventListener("DOMContentLoaded", () => {
  applyStoreSettings();
  renderCategories();
  renderProducts();
  renderHeroBanners();
  renderCart();
  updateCartCount();

  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
});

// Cross-tab synchronization: re-render whenever admin updates data
window.addEventListener("storage", (e) => {
  if (e.key && e.key.startsWith("tejasmade_")) {
    applyStoreSettings();
    renderCategories();
    renderProducts(currentCategoryFilter);
    renderHeroBanners();
    updateCartCount();
  }
});

window.addEventListener("tejasmade:data_updated", () => {
  applyStoreSettings();
  renderCategories();
  renderProducts(currentCategoryFilter);
  renderHeroBanners();
  updateCartCount();
});
