/**
 * TEJASMADE — Admin Category Management Controller
 */

let currentCategories = [];
let selectedCategoryImageFile = null;
let currentEditingCategoryId = null;
let pendingCategoryDataUrl = null;

document.addEventListener("DOMContentLoaded", () => {
  if (!AdminAuth.protectPage()) return;

  loadCategories();
  setupEventListeners();

  window.addEventListener("tejasmade:data_updated", (e) => {
    if (e.detail && (e.detail.type === "categories" || e.detail.type === "all")) {
      loadCategories();
    }
  });
});

function loadCategories() {
  currentCategories = StorageService.getCategories();
  renderCategoriesTable();
}

function renderCategoriesTable() {
  const tableBody = document.getElementById("categories-table-tbody");
  const countBadge = document.getElementById("categories-count-badge");
  const products = StorageService.getProducts();

  if (countBadge) countBadge.textContent = currentCategories.length;

  if (!currentCategories.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="7" class="empty-state">
          <div class="empty-icon">🏷️</div>
          <h3>No categories found</h3>
          <p>Create categories to group your customized products for easy customer browsing.</p>
          <button type="button" class="btn btn-primary btn-sm" onclick="openCategoryModal()">+ Add Category</button>
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = currentCategories.map(cat => {
    const isAct = cat.active !== false;
    const catProducts = products.filter(p => p.category === cat.slug || p.category === cat.id);
    const prodCount = catProducts.length;

    const imgTag = cat.image 
      ? `<img class="item-thumb" data-img-src="${escapeHtml(cat.image)}" alt="${escapeHtml(cat.name)}" src="assets/tejasmade-logo.png">`
      : `<div class="item-thumb-placeholder">${escapeHtml(cat.icon || "🏷️")}</div>`;

    return `
      <tr>
        <td>
          <div class="item-cell">
            ${imgTag}
            <div class="item-info">
              <strong>${escapeHtml(cat.name)}</strong>
              <small>Slug: <code>${escapeHtml(cat.slug || cat.id)}</code></small>
            </div>
          </div>
        </td>
        <td><span style="font-size: 16px;">${escapeHtml(cat.icon || "✦")}</span></td>
        <td>${escapeHtml(cat.subtitle || "—")}</td>
        <td><span class="badge badge-category">${prodCount} products</span></td>
        <td><span class="badge badge-order">#${cat.order || 1}</span></td>
        <td>
          <label class="switch" title="Toggle active status">
            <input type="checkbox" ${isAct ? "checked" : ""} onchange="handleToggleCategoryStatus('${escapeHtml(cat.id)}')">
            <span class="slider"></span>
          </label>
        </td>
        <td>
          <div class="table-actions">
            <button type="button" class="action-btn" title="Edit Category" onclick="openCategoryModal('${escapeHtml(cat.id)}')">✏️</button>
            <button type="button" class="action-btn delete-btn" title="Delete Category" onclick="promptDeleteCategory('${escapeHtml(cat.id)}')">🗑️</button>
            <a href="index.html#categories" target="_blank" class="action-btn" title="View on storefront">↗</a>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(tableBody);
}

function setupEventListeners() {
  const fileInput = document.getElementById("cat-image-file");
  const uploadZone = document.getElementById("cat-upload-zone");

  if (fileInput) fileInput.addEventListener("change", handleCategoryImageSelect);

  if (uploadZone) {
    ["dragenter", "dragover"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.add("dragover"); });
    });
    ["dragleave", "drop"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.remove("dragover"); });
    });
    uploadZone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        fileInput.files = e.dataTransfer.files;
        handleCategoryImageSelect({ target: fileInput });
      }
    });
  }

  // Auto-generate slug from name if adding new category
  const nameInput = document.getElementById("cat-name-input");
  const slugInput = document.getElementById("cat-slug-input");
  if (nameInput && slugInput) {
    nameInput.addEventListener("input", () => {
      if (!currentEditingCategoryId) {
        slugInput.value = nameInput.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      }
    });
  }

  const form = document.getElementById("cat-modal-form");
  if (form) form.addEventListener("submit", handleSaveCategory);
}

function handleCategoryImageSelect(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
    AdminUI.toast("Please upload a valid image (JPG, PNG, WEBP).", "error");
    return;
  }

  selectedCategoryImageFile = file;

  const reader = new FileReader();
  reader.onload = (evt) => {
    pendingCategoryDataUrl = evt.target.result;
    displayCategoryImagePreview(pendingCategoryDataUrl);
  };
  reader.readAsDataURL(file);
}

function displayCategoryImagePreview(src) {
  const wrapper = document.getElementById("cat-image-preview-wrapper");
  const img = document.getElementById("cat-image-preview-img");
  const promptEl = document.getElementById("cat-upload-prompt");

  if (src) {
    img.src = src;
    wrapper.style.display = "block";
    if (promptEl) promptEl.style.display = "none";
  } else {
    wrapper.style.display = "none";
    if (promptEl) promptEl.style.display = "block";
  }
}

function removeSelectedCategoryImage() {
  selectedCategoryImageFile = null;
  pendingCategoryDataUrl = null;
  const fileInput = document.getElementById("cat-image-file");
  if (fileInput) fileInput.value = "";
  const urlInput = document.getElementById("cat-image-url-input");
  if (urlInput) urlInput.value = "";
  displayCategoryImagePreview(null);
}

function openCategoryModal(categoryId = null) {
  currentEditingCategoryId = categoryId;
  selectedCategoryImageFile = null;
  pendingCategoryDataUrl = null;

  const modal = document.getElementById("category-modal");
  const modalTitle = document.getElementById("category-modal-title");
  const nameInput = document.getElementById("cat-name-input");
  const slugInput = document.getElementById("cat-slug-input");
  const subtitleInput = document.getElementById("cat-subtitle-input");
  const iconInput = document.getElementById("cat-icon-input");
  const orderInput = document.getElementById("cat-order-input");
  const activeCheckbox = document.getElementById("cat-active-input");
  const urlInput = document.getElementById("cat-image-url-input");

  removeSelectedCategoryImage();

  if (categoryId) {
    const cat = StorageService.getCategoryById(categoryId);
    if (!cat) return;

    modalTitle.textContent = "Edit Category";
    nameInput.value = cat.name || "";
    slugInput.value = cat.slug || cat.id;
    slugInput.readOnly = true;
    subtitleInput.value = cat.subtitle || "";
    iconInput.value = cat.icon || "✦";
    orderInput.value = cat.order || 1;
    activeCheckbox.checked = cat.active !== false;

    if (cat.image) {
      urlInput.value = cat.image;
      StorageService.resolveImageSource(cat.image).then(resolved => {
        displayCategoryImagePreview(resolved);
      });
    }
  } else {
    modalTitle.textContent = "Add New Category";
    nameInput.value = "";
    slugInput.value = "";
    slugInput.readOnly = false;
    subtitleInput.value = "";
    iconInput.value = "✦";
    orderInput.value = currentCategories.length + 1;
    activeCheckbox.checked = true;
    urlInput.value = "";
    displayCategoryImagePreview(null);
  }

  modal.classList.add("active");
}

function closeCategoryModal() {
  const modal = document.getElementById("category-modal");
  if (modal) modal.classList.remove("active");
  currentEditingCategoryId = null;
  selectedCategoryImageFile = null;
  pendingCategoryDataUrl = null;
}

async function handleSaveCategory(e) {
  e.preventDefault();

  const nameInput = document.getElementById("cat-name-input");
  const slugInput = document.getElementById("cat-slug-input");
  const subtitleInput = document.getElementById("cat-subtitle-input");
  const iconInput = document.getElementById("cat-icon-input");
  const orderInput = document.getElementById("cat-order-input");
  const activeCheckbox = document.getElementById("cat-active-input");
  const urlInput = document.getElementById("cat-image-url-input");
  const saveBtn = document.getElementById("cat-save-btn");

  const name = nameInput.value.trim();
  const slug = slugInput.value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  if (!name || !slug) {
    AdminUI.toast("Category name and slug are required.", "error");
    return;
  }

  if (!currentEditingCategoryId) {
    if (StorageService.getCategoryById(slug)) {
      AdminUI.toast(`A category with slug "${slug}" already exists. Please choose a unique slug.`, "error");
      slugInput.focus();
      return;
    }
  }

  saveBtn.disabled = true;
  saveBtn.textContent = "Saving Category...";

  try {
    let finalImage = urlInput.value || "";
    let finalImageId = null;

    if (selectedCategoryImageFile) {
      const uploadResult = await StorageService.processAndSaveImageFile(selectedCategoryImageFile, 1920, 1080);
      finalImageId = uploadResult.imageId;
      finalImage = uploadResult.imageId;
    }

    if (!finalImage && !currentEditingCategoryId) {
      finalImage = "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=3840&q=88";
    }

    const categoryPayload = {
      id: currentEditingCategoryId || slug,
      slug: slug,
      name: name,
      label: name,
      subtitle: subtitleInput.value.trim(),
      icon: iconInput.value.trim() || "✦",
      order: Number(orderInput.value) || 1,
      active: activeCheckbox.checked,
      image: finalImage,
      imageId: finalImageId
    };

    StorageService.upsertCategory(categoryPayload);

    AdminUI.toast(
      currentEditingCategoryId ? `Category "${name}" updated successfully.` : `Category "${name}" created successfully.`,
      "success"
    );

    closeCategoryModal();
    loadCategories();
  } catch (err) {
    console.error("Save category error:", err);
    AdminUI.toast("Failed to save category: " + (err.message || "Unknown error"), "error");
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = "Save Category";
  }
}

function handleToggleCategoryStatus(categoryId) {
  const newStatus = StorageService.toggleCategoryStatus(categoryId);
  AdminUI.toast(`Category is now ${newStatus ? "Active" : "Inactive"}.`, "success");
  loadCategories();
}

function promptDeleteCategory(categoryId) {
  const cat = StorageService.getCategoryById(categoryId);
  if (!cat) return;

  const products = StorageService.getProducts();
  const linked = products.filter(p => p.category === cat.slug || p.category === cat.id);

  let warning = "";
  if (linked.length > 0) {
    warning = `<br><span style="color:var(--danger); font-size:12px;"><strong>Warning:</strong> ${linked.length} product(s) are currently assigned to this category.</span>`;
  }

  AdminUI.confirm({
    title: "Delete Category?",
    message: `Are you sure you want to delete category <strong>"${escapeHtml(cat.name)}"</strong>?${warning}`,
    confirmText: "Delete Category",
    confirmClass: "btn-danger",
    onConfirm: () => {
      StorageService.deleteCategory(categoryId);
      AdminUI.toast("Category deleted successfully.", "success");
      loadCategories();
    }
  });
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));
}

window.openCategoryModal = openCategoryModal;
window.closeCategoryModal = closeCategoryModal;
window.handleToggleCategoryStatus = handleToggleCategoryStatus;
window.promptDeleteCategory = promptDeleteCategory;
window.removeSelectedCategoryImage = removeSelectedCategoryImage;
