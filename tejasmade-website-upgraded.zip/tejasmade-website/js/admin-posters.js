/**
 * TEJASMADE — Admin Poster and Banner Management Controller
 */

let currentPosters = [];
let selectedPosterImageFile = null;
let currentEditingPosterId = null;
let pendingPosterDataUrl = null;

document.addEventListener("DOMContentLoaded", () => {
  if (!AdminAuth.protectPage()) return;

  loadPosters();
  setupEventListeners();

  const params = new URLSearchParams(window.location.search);
  if (params.get("action") === "new") {
    openPosterModal();
  }

  window.addEventListener("tejasmade:data_updated", (e) => {
    if (e.detail && (e.detail.type === "posters" || e.detail.type === "all")) {
      loadPosters();
    }
  });
});

function loadPosters() {
  currentPosters = StorageService.getPosters();
  renderPostersGrid();
}

function renderPostersGrid() {
  const container = document.getElementById("posters-grid-container");
  const countBadge = document.getElementById("posters-count-badge");
  const searchInput = (document.getElementById("poster-search-input")?.value || "").toLowerCase().trim();
  const statusFilter = document.getElementById("poster-status-filter")?.value || "all";

  let filtered = currentPosters.filter(p => {
    const matchesSearch = !searchInput ||
      (p.title && p.title.toLowerCase().includes(searchInput)) ||
      (p.subtitle && p.subtitle.toLowerCase().includes(searchInput)) ||
      (p.offerBadge && p.offerBadge.toLowerCase().includes(searchInput));

    const isAct = p.active !== false;
    const matchesStatus = statusFilter === "all" ||
      (statusFilter === "active" && isAct) ||
      (statusFilter === "inactive" && !isAct);

    return matchesSearch && matchesStatus;
  });

  if (countBadge) countBadge.textContent = `${filtered.length} of ${currentPosters.length}`;

  if (!filtered.length) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🖼️</div>
        <h3>No promotional posters found</h3>
        <p>Upload your promotional campaigns, festival offers, or corporate banners.</p>
        <button type="button" class="btn btn-primary btn-sm" onclick="openPosterModal()">+ Create New Poster</button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(poster => {
    const isAct = poster.active !== false;
    const statusBadge = isAct
      ? '<span class="badge badge-active">Active</span>'
      : '<span class="badge badge-inactive">Inactive</span>';

    return `
      <div class="poster-admin-card">
        <div class="poster-media-preview" data-bg-src="${escapeHtml(poster.image || '')}">
          <div class="poster-preview-title">${escapeHtml(poster.title)}</div>
        </div>
        <div class="poster-admin-body">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
            <span class="badge badge-order">Slide #${poster.order || 1}</span>
            ${poster.offerBadge ? `<span class="badge badge-category" style="background:#fef3c7; color:#92400e; border-color:#fde68a;">${escapeHtml(poster.offerBadge)}</span>` : ''}
          </div>
          <p>${escapeHtml(poster.subtitle || "No subtitle provided.")}</p>
          <div style="font-size: 11.5px; color: var(--muted); margin-bottom: 12px;">
            <strong>Button:</strong> "${escapeHtml(poster.buttonText || 'Explore')}" → <code>${escapeHtml(poster.buttonLink || '#products')}</code>
          </div>
          <div class="poster-meta-row">
            <div style="display: flex; align-items: center; gap: 8px;">
              <label class="switch" title="Toggle active status">
                <input type="checkbox" ${isAct ? "checked" : ""} onchange="handleTogglePosterStatus('${escapeHtml(poster.id)}')">
                <span class="slider"></span>
              </label>
              ${statusBadge}
            </div>
            <div class="table-actions">
              <button type="button" class="action-btn" title="Edit Poster" onclick="openPosterModal('${escapeHtml(poster.id)}')">✏️</button>
              <button type="button" class="action-btn delete-btn" title="Delete Poster" onclick="promptDeletePoster('${escapeHtml(poster.id)}')">🗑️</button>
              <a href="index.html#home" target="_blank" class="action-btn" title="View on storefront">↗</a>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(container);
}

function setupEventListeners() {
  const searchInput = document.getElementById("poster-search-input");
  const statusFilter = document.getElementById("poster-status-filter");
  if (searchInput) searchInput.addEventListener("input", renderPostersGrid);
  if (statusFilter) statusFilter.addEventListener("change", renderPostersGrid);

  const fileInput = document.getElementById("poster-image-file");
  const uploadZone = document.getElementById("poster-upload-zone");

  if (fileInput) fileInput.addEventListener("change", handlePosterImageSelect);

  if (uploadZone) {
    ["dragenter", "dragover"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.add("dragover"); });
    });
    ["dragleave", "drop"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.remove("dragover"); });
    });
    uploadZone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        fileInput.files = e.dataTransfer.files;
        handlePosterImageSelect({ target: fileInput });
      }
    });
  }

  const form = document.getElementById("poster-modal-form");
  if (form) form.addEventListener("submit", handleSavePoster);
}

function handlePosterImageSelect(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
    AdminUI.toast("Please upload a valid image (JPG, JPEG, PNG, WEBP).", "error");
    return;
  }

  if (file.size > 8 * 1024 * 1024) {
    AdminUI.toast("Image file is too large (max 8MB).", "error");
    return;
  }

  selectedPosterImageFile = file;

  const reader = new FileReader();
  reader.onload = (evt) => {
    pendingPosterDataUrl = evt.target.result;
    displayPosterImagePreview(pendingPosterDataUrl);
  };
  reader.readAsDataURL(file);
}

function displayPosterImagePreview(src) {
  const wrapper = document.getElementById("poster-image-preview-wrapper");
  const img = document.getElementById("poster-image-preview-img");
  const promptEl = document.getElementById("poster-upload-prompt");

  if (src) {
    img.src = src;
    wrapper.style.display = "block";
    if (promptEl) promptEl.style.display = "none";
  } else {
    wrapper.style.display = "none";
    if (promptEl) promptEl.style.display = "block";
  }
}

function removeSelectedPosterImage() {
  selectedPosterImageFile = null;
  pendingPosterDataUrl = null;
  const fileInput = document.getElementById("poster-image-file");
  if (fileInput) fileInput.value = "";
  const urlInput = document.getElementById("poster-image-url-input");
  if (urlInput) urlInput.value = "";
  displayPosterImagePreview(null);
}

function openPosterModal(posterId = null) {
  currentEditingPosterId = posterId;
  selectedPosterImageFile = null;
  pendingPosterDataUrl = null;

  const modal = document.getElementById("poster-modal");
  const modalTitle = document.getElementById("poster-modal-title");
  const titleInput = document.getElementById("poster-title-input");
  const subtitleInput = document.getElementById("poster-subtitle-input");
  const offerBadgeInput = document.getElementById("poster-badge-input");
  const buttonTextInput = document.getElementById("poster-btn-text-input");
  const buttonLinkInput = document.getElementById("poster-btn-link-input");
  const orderInput = document.getElementById("poster-order-input");
  const activeCheckbox = document.getElementById("poster-active-input");
  const urlInput = document.getElementById("poster-image-url-input");

  removeSelectedPosterImage();

  if (posterId) {
    const poster = StorageService.getPosterById(posterId);
    if (!poster) return;

    modalTitle.textContent = "Edit Poster / Banner";
    titleInput.value = poster.title || "";
    subtitleInput.value = poster.subtitle || "";
    offerBadgeInput.value = poster.offerBadge || "";
    buttonTextInput.value = poster.buttonText || "Explore";
    buttonLinkInput.value = poster.buttonLink || "#products";
    orderInput.value = poster.order || 1;
    activeCheckbox.checked = poster.active !== false;

    if (poster.image) {
      urlInput.value = poster.image;
      StorageService.resolveImageSource(poster.image).then(resolved => {
        displayPosterImagePreview(resolved);
      });
    }
  } else {
    modalTitle.textContent = "Create New Poster / Banner";
    titleInput.value = "";
    subtitleInput.value = "";
    offerBadgeInput.value = "";
    buttonTextInput.value = "Explore Collection";
    buttonLinkInput.value = "#products";
    orderInput.value = currentPosters.length + 1;
    activeCheckbox.checked = true;
    urlInput.value = "";
    displayPosterImagePreview(null);
  }

  modal.classList.add("active");
}

function closePosterModal() {
  const modal = document.getElementById("poster-modal");
  if (modal) modal.classList.remove("active");
  currentEditingPosterId = null;
  selectedPosterImageFile = null;
  pendingPosterDataUrl = null;
}

async function handleSavePoster(e) {
  e.preventDefault();

  const titleInput = document.getElementById("poster-title-input");
  const subtitleInput = document.getElementById("poster-subtitle-input");
  const offerBadgeInput = document.getElementById("poster-badge-input");
  const buttonTextInput = document.getElementById("poster-btn-text-input");
  const buttonLinkInput = document.getElementById("poster-btn-link-input");
  const orderInput = document.getElementById("poster-order-input");
  const activeCheckbox = document.getElementById("poster-active-input");
  const urlInput = document.getElementById("poster-image-url-input");
  const saveBtn = document.getElementById("poster-save-btn");

  const title = titleInput.value.trim();
  if (!title) {
    AdminUI.toast("Poster Title is required.", "error");
    titleInput.focus();
    return;
  }

  saveBtn.disabled = true;
  saveBtn.textContent = "Saving Banner...";

  try {
    let finalImage = urlInput.value || "";
    let finalImageId = null;

    if (selectedPosterImageFile) {
      const uploadResult = await StorageService.processAndSaveImageFile(selectedPosterImageFile, 2400, 1400);
      finalImageId = uploadResult.imageId;
      finalImage = uploadResult.imageId;
    }

    if (!finalImage && !currentEditingPosterId) {
      // If no image uploaded, provide fallback aesthetic unsplash image
      finalImage = "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=3840&q=88";
    }

    const posterPayload = {
      id: currentEditingPosterId || ("poster_" + Date.now()),
      title: title,
      subtitle: subtitleInput.value.trim(),
      offerBadge: offerBadgeInput.value.trim(),
      buttonText: buttonTextInput.value.trim() || "Explore",
      buttonLink: buttonLinkInput.value.trim() || "#products",
      order: Number(orderInput.value) || 1,
      active: activeCheckbox.checked,
      image: finalImage,
      imageId: finalImageId
    };

    StorageService.upsertPoster(posterPayload);

    AdminUI.toast(
      currentEditingPosterId ? `Poster "${title}" updated successfully.` : `New poster "${title}" created successfully.`,
      "success"
    );

    closePosterModal();
    loadPosters();
  } catch (err) {
    console.error("Save poster error:", err);
    AdminUI.toast("Failed to save poster: " + (err.message || "Unknown error"), "error");
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = "Save Poster";
  }
}

function handleTogglePosterStatus(posterId) {
  const newStatus = StorageService.togglePosterStatus(posterId);
  AdminUI.toast(`Poster is now ${newStatus ? "Active on homepage" : "Hidden from homepage"}.`, "success");
  loadPosters();
}

function promptDeletePoster(posterId) {
  const poster = StorageService.getPosterById(posterId);
  if (!poster) return;

  AdminUI.confirm({
    title: "Delete Poster?",
    message: `Are you sure you want to remove promotional banner <strong>"${escapeHtml(poster.title)}"</strong>?`,
    confirmText: "Delete Poster",
    confirmClass: "btn-danger",
    onConfirm: () => {
      StorageService.deletePoster(posterId);
      AdminUI.toast("Poster deleted successfully.", "success");
      loadPosters();
    }
  });
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));
}

window.openPosterModal = openPosterModal;
window.closePosterModal = closePosterModal;
window.handleTogglePosterStatus = handleTogglePosterStatus;
window.promptDeletePoster = promptDeletePoster;
window.removeSelectedPosterImage = removeSelectedPosterImage;
