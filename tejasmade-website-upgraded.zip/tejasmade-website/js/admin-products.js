/**
 * TEJASMADE — Admin Product Management Controller
 */

let currentProducts = [];
let currentCategories = [];
let selectedImageFile = null;
let currentEditingProductId = null;
let pendingImageDataUrl = null;

document.addEventListener("DOMContentLoaded", () => {
  if (!AdminAuth.protectPage()) return;

  loadCategories();
  loadProducts();
  setupEventListeners();

  // Check URL query parameters for action
  const params = new URLSearchParams(window.location.search);
  if (params.get("action") === "new") {
    openProductModal();
  } else if (params.get("edit")) {
    openProductModal(params.get("edit"));
  }

  // Cross-tab sync
  window.addEventListener("tejasmade:data_updated", (e) => {
    if (e.detail && (e.detail.type === "products" || e.detail.type === "categories" || e.detail.type === "all")) {
      loadCategories();
      loadProducts();
    }
  });
});

function loadCategories() {
  currentCategories = StorageService.getCategories();

  // Populate category filter dropdown
  const filterSelect = document.getElementById("product-category-filter");
  if (filterSelect) {
    const currentVal = filterSelect.value;
    filterSelect.innerHTML = '<option value="all">All Categories</option>' +
      currentCategories.map(c => `<option value="${escapeHtml(c.slug || c.id)}">${escapeHtml(c.name || c.label)}</option>`).join("");
    if (currentVal) filterSelect.value = currentVal;
  }

  // Populate modal category dropdown
  const modalCategorySelect = document.getElementById("product-category-input");
  if (modalCategorySelect) {
    modalCategorySelect.innerHTML = currentCategories.map(c => 
      `<option value="${escapeHtml(c.slug || c.id)}">${escapeHtml(c.name || c.label)}</option>`
    ).join("");
  }
}

function loadProducts() {
  currentProducts = StorageService.getProducts();
  renderProductsTable();
}

function renderProductsTable() {
  const tableBody = document.getElementById("products-table-tbody");
  const countEl = document.getElementById("products-count-badge");
  const searchQuery = (document.getElementById("product-search-input")?.value || "").toLowerCase().trim();
  const categoryFilter = document.getElementById("product-category-filter")?.value || "all";
  const statusFilter = document.getElementById("product-status-filter")?.value || "all";

  let filtered = currentProducts.filter(p => {
    // Search match
    const matchesSearch = !searchQuery || 
      (p.name && p.name.toLowerCase().includes(searchQuery)) ||
      (p.id && p.id.toLowerCase().includes(searchQuery)) ||
      (p.description && p.description.toLowerCase().includes(searchQuery)) ||
      (p.label && p.label.toLowerCase().includes(searchQuery));

    // Category match
    const matchesCategory = categoryFilter === "all" || p.category === categoryFilter;

    // Status match
    const isAct = p.active !== false;
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && isAct) || 
      (statusFilter === "inactive" && !isAct);

    return matchesSearch && matchesCategory && matchesStatus;
  });

  if (countEl) countEl.textContent = `${filtered.length} of ${currentProducts.length}`;

  if (!filtered.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6" class="empty-state">
          <div class="empty-icon">📦</div>
          <h3>No matching products found</h3>
          <p>Try modifying your search or category filters, or click "+ Add Product" to create one.</p>
          <button type="button" class="btn btn-primary btn-sm" onclick="openProductModal()">+ Add Product</button>
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = filtered.map(p => {
    const isAct = p.active !== false;
    const isEnquiry = !p.price || p.pricingType === "enquiry";
    const priceDisplay = isEnquiry 
      ? '<span style="color:var(--muted); font-size:12px;">Enquiry Only</span>' 
      : `<strong style="color:var(--primary); font-size:13.5px;">${escapeHtml(p.price)}</strong>`;

    const imgTag = p.image 
      ? `<img class="item-thumb" data-img-src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" src="assets/tejasmade-logo.png">`
      : `<div class="item-thumb-placeholder">${escapeHtml(p.icon || "📦")}</div>`;

    const categoryObj = currentCategories.find(c => c.slug === p.category || c.id === p.category);
    const catLabel = categoryObj ? (categoryObj.label || categoryObj.name) : (p.label || p.category);

    return `
      <tr>
        <td>
          <div class="item-cell">
            ${imgTag}
            <div class="item-info">
              <strong>${escapeHtml(p.name)}</strong>
              <small>ID: ${escapeHtml(p.id)}</small>
            </div>
          </div>
        </td>
        <td><span class="badge badge-category">${escapeHtml(catLabel)}</span></td>
        <td>${priceDisplay}</td>
        <td>
          <label class="switch" title="Toggle active status">
            <input type="checkbox" ${isAct ? "checked" : ""} onchange="handleToggleStatus('${escapeHtml(p.id)}')">
            <span class="slider"></span>
          </label>
        </td>
        <td>
          ${isAct ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-inactive">Inactive</span>'}
        </td>
        <td>
          <div class="table-actions">
            <button type="button" class="action-btn" title="Edit Product" onclick="openProductModal('${escapeHtml(p.id)}')">✏️</button>
            <button type="button" class="action-btn delete-btn" title="Delete Product" onclick="promptDeleteProduct('${escapeHtml(p.id)}')">🗑️</button>
            <a href="index.html#products" target="_blank" class="action-btn" title="View on storefront">↗</a>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(tableBody);
}

function setupEventListeners() {
  // Search & Filter change events
  const searchInput = document.getElementById("product-search-input");
  const catFilter = document.getElementById("product-category-filter");
  const statusFilter = document.getElementById("product-status-filter");

  if (searchInput) searchInput.addEventListener("input", renderProductsTable);
  if (catFilter) catFilter.addEventListener("change", renderProductsTable);
  if (statusFilter) statusFilter.addEventListener("change", renderProductsTable);

  // File upload input inside modal
  const fileInput = document.getElementById("product-image-file");
  const uploadZone = document.getElementById("product-upload-zone");

  if (fileInput) {
    fileInput.addEventListener("change", handleImageFileSelect);
  }

  // Drag and drop for upload zone
  if (uploadZone) {
    ["dragenter", "dragover"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.add("dragover"); });
    });
    ["dragleave", "drop"].forEach(evt => {
      uploadZone.addEventListener(evt, (e) => { e.preventDefault(); uploadZone.classList.remove("dragover"); });
    });
    uploadZone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        fileInput.files = e.dataTransfer.files;
        handleImageFileSelect({ target: fileInput });
      }
    });
  }

  // Pricing type toggle radio/select
  const pricingTypeRadios = document.querySelectorAll("input[name='product_pricing_type']");
  pricingTypeRadios.forEach(radio => {
    radio.addEventListener("change", () => {
      const isFixed = document.getElementById("pricing-type-fixed").checked;
      const priceInputGroup = document.getElementById("price-input-group");
      if (priceInputGroup) priceInputGroup.style.display = isFixed ? "block" : "none";
    });
  });

  // Save Product Form
  const form = document.getElementById("product-modal-form");
  if (form) {
    form.addEventListener("submit", handleSaveProduct);
  }
}

async function handleImageFileSelect(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
    AdminUI.toast("Please select a valid image file (JPG, JPEG, PNG, or WEBP).", "error");
    return;
  }

  if (file.size > 8 * 1024 * 1024) {
    AdminUI.toast("Image file is too large (max 8MB).", "error");
    return;
  }

  selectedImageFile = file;

  // Show preview immediately using FileReader
  const reader = new FileReader();
  reader.onload = (evt) => {
    pendingImageDataUrl = evt.target.result;
    displayImagePreview(pendingImageDataUrl);
  };
  reader.readAsDataURL(file);
}

function displayImagePreview(src) {
  const previewWrapper = document.getElementById("product-image-preview-wrapper");
  const previewImg = document.getElementById("product-image-preview-img");
  const promptEl = document.getElementById("product-upload-prompt");

  if (src) {
    previewImg.src = src;
    previewWrapper.style.display = "block";
    if (promptEl) promptEl.style.display = "none";
  } else {
    previewWrapper.style.display = "none";
    if (promptEl) promptEl.style.display = "block";
  }
}

function removeSelectedImage() {
  selectedImageFile = null;
  pendingImageDataUrl = null;
  const fileInput = document.getElementById("product-image-file");
  if (fileInput) fileInput.value = "";
  const existingUrlInput = document.getElementById("product-image-url-input");
  if (existingUrlInput) existingUrlInput.value = "";
  displayImagePreview(null);
}

function openProductModal(productId = null) {
  currentEditingProductId = productId;
  selectedImageFile = null;
  pendingImageDataUrl = null;

  const modal = document.getElementById("product-modal");
  const modalTitle = document.getElementById("product-modal-title");
  const idInput = document.getElementById("product-id-input");
  const nameInput = document.getElementById("product-name-input");
  const categorySelect = document.getElementById("product-category-input");
  const descInput = document.getElementById("product-desc-input");
  const activeCheckbox = document.getElementById("product-active-input");
  const priceInput = document.getElementById("product-price-input");
  const pricingFixed = document.getElementById("pricing-type-fixed");
  const pricingEnquiry = document.getElementById("pricing-type-enquiry");
  const priceInputGroup = document.getElementById("price-input-group");
  const existingUrlInput = document.getElementById("product-image-url-input");

  removeSelectedImage();

  if (productId) {
    const product = StorageService.getProductById(productId);
    if (!product) {
      AdminUI.toast("Product not found.", "error");
      return;
    }

    modalTitle.textContent = "Edit Product";
    idInput.value = product.id;
    idInput.readOnly = true;
    nameInput.value = product.name || "";
    categorySelect.value = product.category || (currentCategories[0]?.slug || "");
    descInput.value = product.description || "";
    activeCheckbox.checked = product.active !== false;

    if (product.pricingType === "fixed" && product.price) {
      pricingFixed.checked = true;
      priceInput.value = product.price;
      priceInputGroup.style.display = "block";
    } else {
      pricingEnquiry.checked = true;
      priceInput.value = "";
      priceInputGroup.style.display = "none";
    }

    if (product.image) {
      existingUrlInput.value = product.image;
      StorageService.resolveImageSource(product.image).then(resolved => {
        displayImagePreview(resolved);
      });
    }
  } else {
    modalTitle.textContent = "Add New Product";
    // Generate clean unique ID
    const nextNum = currentProducts.length + 1;
    idInput.value = "tm" + String(nextNum).padStart(3, "0");
    idInput.readOnly = false;
    nameInput.value = "";
    if (currentCategories.length) categorySelect.value = currentCategories[0].slug || currentCategories[0].id;
    descInput.value = "";
    activeCheckbox.checked = true;
    pricingEnquiry.checked = true;
    priceInput.value = "";
    priceInputGroup.style.display = "none";
    existingUrlInput.value = "";
    displayImagePreview(null);
  }

  modal.classList.add("active");
}

function closeProductModal() {
  const modal = document.getElementById("product-modal");
  if (modal) modal.classList.remove("active");
  currentEditingProductId = null;
  selectedImageFile = null;
  pendingImageDataUrl = null;
}

async function handleSaveProduct(e) {
  e.preventDefault();

  const idInput = document.getElementById("product-id-input");
  const nameInput = document.getElementById("product-name-input");
  const categorySelect = document.getElementById("product-category-input");
  const descInput = document.getElementById("product-desc-input");
  const activeCheckbox = document.getElementById("product-active-input");
  const priceInput = document.getElementById("product-price-input");
  const pricingFixed = document.getElementById("pricing-type-fixed");
  const existingUrlInput = document.getElementById("product-image-url-input");
  const saveBtn = document.getElementById("product-save-btn");

  const id = idInput.value.trim();
  const name = nameInput.value.trim();
  const category = categorySelect.value;
  const description = descInput.value.trim();
  const active = activeCheckbox.checked;
  const isFixedPrice = pricingFixed.checked;
  const price = isFixedPrice ? priceInput.value.trim() : "";

  if (!id) {
    AdminUI.toast("Product ID is required.", "error");
    idInput.focus();
    return;
  }

  if (!name) {
    AdminUI.toast("Product Name is required.", "error");
    nameInput.focus();
    return;
  }

  // Check duplicate ID if new product
  if (!currentEditingProductId) {
    if (StorageService.getProductById(id)) {
      AdminUI.toast(`A product with ID "${id}" already exists. Please choose a unique ID.`, "error");
      idInput.focus();
      return;
    }
  }

  // Disable save button to prevent double clicks
  saveBtn.disabled = true;
  saveBtn.textContent = "Saving Product...";

  try {
    let finalImageReference = existingUrlInput.value || "";
    let finalImageId = null;

    // If a new local image file was chosen, process and save to IndexedDB
    if (selectedImageFile) {
      const uploadResult = await StorageService.processAndSaveImageFile(selectedImageFile);
      finalImageId = uploadResult.imageId;
      finalImageReference = uploadResult.imageId; // Stored in IndexedDB
    }

    const categoryObj = currentCategories.find(c => c.slug === category || c.id === category);
    const categoryLabel = categoryObj ? (categoryObj.label || categoryObj.name) : category;
    const categoryIcon = categoryObj ? categoryObj.icon : "📦";

    const productPayload = {
      id: id,
      name: name,
      category: category,
      label: categoryLabel,
      description: description,
      icon: categoryIcon,
      image: finalImageReference,
      imageId: finalImageId,
      price: price,
      pricingType: isFixedPrice ? "fixed" : "enquiry",
      active: active
    };

    StorageService.upsertProduct(productPayload);

    AdminUI.toast(
      currentEditingProductId ? `Product "${name}" updated successfully.` : `Product "${name}" added successfully.`,
      "success"
    );

    closeProductModal();
    loadProducts();
  } catch (err) {
    console.error("Save product error:", err);
    AdminUI.toast("Error saving product: " + (err.message || "Unknown error"), "error");
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = "Save Product";
  }
}

function handleToggleStatus(productId) {
  const newStatus = StorageService.toggleProductStatus(productId);
  AdminUI.toast(`Product is now ${newStatus ? "Active" : "Inactive"}.`, "success");
  loadProducts();
}

function promptDeleteProduct(productId) {
  const product = StorageService.getProductById(productId);
  if (!product) return;

  AdminUI.confirm({
    title: "Delete Product?",
    message: `Are you sure you want to permanently delete <strong>${escapeHtml(product.name)}</strong> (ID: ${escapeHtml(product.id)})? This will remove it from the store catalog.`,
    confirmText: "Yes, Delete",
    confirmClass: "btn-danger",
    onConfirm: () => {
      StorageService.deleteProduct(productId);
      AdminUI.toast(`Product "${product.name}" has been deleted.`, "success");
      loadProducts();
    }
  });
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));
}

window.openProductModal = openProductModal;
window.closeProductModal = closeProductModal;
window.handleToggleStatus = handleToggleStatus;
window.promptDeleteProduct = promptDeleteProduct;
window.removeSelectedImage = removeSelectedImage;
