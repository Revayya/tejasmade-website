/**
 * TEJASMADE — Admin Dashboard Controller
 */

document.addEventListener("DOMContentLoaded", () => {
  // Protect page
  if (!AdminAuth.protectPage()) return;

  renderDashboard();

  // Listen for storage changes across tabs or windows
  window.addEventListener("tejasmade:data_updated", () => {
    renderDashboard();
  });
});

function renderDashboard() {
  const stats = StorageService.getStats();
  const products = StorageService.getProducts();
  const posters = StorageService.getPosters();
  const categories = StorageService.getCategories();
  const settings = StorageService.getSettings();

  // Update KPI Stats Cards
  document.getElementById("stat-total-products").textContent = stats.totalProducts;
  document.getElementById("stat-active-products").textContent = stats.activeProducts;
  document.getElementById("stat-total-categories").textContent = stats.totalCategories;
  document.getElementById("stat-active-posters").textContent = stats.activePosters;

  // Website status pill
  const statusEl = document.getElementById("stat-website-status");
  if (statusEl) {
    statusEl.innerHTML = `<span class="status-dot-live"></span> Live (${stats.activeProducts} items active)`;
  }

  // Render Recent Products (up to 5 latest)
  renderRecentProducts(products.slice(0, 5));

  // Render Recent Promotional Posters
  renderRecentPosters(posters.slice(0, 4));

  // Update counts on badges in sidebar
  const prodBadge = document.getElementById("sidebar-prod-count");
  if (prodBadge) prodBadge.textContent = stats.totalProducts;

  const posterBadge = document.getElementById("sidebar-poster-count");
  if (posterBadge) posterBadge.textContent = stats.totalPosters;

  const catBadge = document.getElementById("sidebar-cat-count");
  if (catBadge) catBadge.textContent = stats.totalCategories;
}

function renderRecentProducts(items) {
  const tableBody = document.getElementById("recent-products-tbody");
  if (!tableBody) return;

  if (!items || !items.length) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="5" class="empty-state" style="padding: 24px;">
          <div style="font-size: 28px; color: var(--muted); margin-bottom: 6px;">📦</div>
          <div style="font-weight: 600;">No products created yet</div>
          <p style="margin: 4px 0 10px; font-size: 12px; color: var(--muted);">Click "+ Add Product" to populate your store catalog.</p>
          <a href="admin-products.html?action=new" class="btn btn-primary btn-sm">+ Add First Product</a>
        </td>
      </tr>
    `;
    return;
  }

  tableBody.innerHTML = items.map(p => {
    const isEnquiry = !p.price || p.pricingType === "enquiry";
    const priceDisplay = isEnquiry ? '<span style="color:var(--muted); font-size:12px;">Enquiry Only</span>' : `<strong style="color:var(--primary);">${escapeHtml(p.price)}</strong>`;
    const statusBadge = p.active !== false
      ? `<span class="badge badge-active">Active</span>`
      : `<span class="badge badge-inactive">Inactive</span>`;

    const imgTag = p.image 
      ? `<img class="item-thumb" data-img-src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" src="assets/tejasmade-logo.png">`
      : `<div class="item-thumb-placeholder">${escapeHtml(p.icon || "📦")}</div>`;

    return `
      <tr>
        <td>
          <div class="item-cell">
            ${imgTag}
            <div class="item-info">
              <strong>${escapeHtml(p.name)}</strong>
              <small>ID: ${escapeHtml(p.id)}</small>
            </div>
          </div>
        </td>
        <td><span class="badge badge-category">${escapeHtml(p.label || p.category)}</span></td>
        <td>${priceDisplay}</td>
        <td>${statusBadge}</td>
        <td>
          <div class="table-actions">
            <a href="admin-products.html?edit=${encodeURIComponent(p.id)}" class="action-btn" title="Edit Product">✏️</a>
            <a href="index.html#products" target="_blank" class="action-btn" title="View on Public Website">↗</a>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(tableBody);
}

function renderRecentPosters(posters) {
  const container = document.getElementById("recent-posters-grid");
  if (!container) return;

  if (!posters || !posters.length) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1; padding: 24px;">
        <div style="font-size: 28px; color: var(--muted); margin-bottom: 6px;">🖼️</div>
        <div style="font-weight: 600;">No posters created yet</div>
        <p style="margin: 4px 0 10px; font-size: 12px; color: var(--muted);">Promotional banners will be displayed here and on the homepage.</p>
        <a href="admin-posters.html" class="btn btn-primary btn-sm">+ Add Poster</a>
      </div>
    `;
    return;
  }

  container.innerHTML = posters.map(poster => {
    const statusBadge = poster.active !== false
      ? `<span class="badge badge-active">Active</span>`
      : `<span class="badge badge-inactive">Inactive</span>`;

    return `
      <div class="poster-admin-card">
        <div class="poster-media-preview" data-bg-src="${escapeHtml(poster.image || '')}">
          <div class="poster-preview-title">${escapeHtml(poster.title)}</div>
        </div>
        <div class="poster-admin-body">
          <p>${escapeHtml(poster.subtitle || "No description provided.")}</p>
          <div class="poster-meta-row">
            <div>
              <span class="badge badge-order">Order #${poster.order || 1}</span>
              ${statusBadge}
            </div>
            <a href="admin-posters.html" class="btn btn-secondary btn-sm">Manage</a>
          </div>
        </div>
      </div>
    `;
  }).join("");

  StorageService.hydrateDynamicImages(container);
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[c]));
}
