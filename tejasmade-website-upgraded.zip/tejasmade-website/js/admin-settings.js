/**
 * TEJASMADE — Admin Website Settings Controller
 */

let selectedLogoFile = null;
let pendingLogoDataUrl = null;

document.addEventListener("DOMContentLoaded", () => {
  if (!AdminAuth.protectPage()) return;

  loadSettings();
  setupEventListeners();
});

function loadSettings() {
  const settings = StorageService.getSettings();
  const auth = StorageService.getAuth();

  // General & Branding
  document.getElementById("setting-site-name").value = settings.siteName || "TEJASMADE";
  document.getElementById("setting-announcement").value = settings.announcement || "";
  document.getElementById("setting-whatsapp").value = settings.whatsappNumber || "919606799579";
  document.getElementById("setting-email").value = settings.email || "tejasmadeofficial@gmail.com";
  document.getElementById("setting-instagram-url").value = settings.instagramUrl || "";
  document.getElementById("setting-instagram-handle").value = settings.instagramHandle || "";

  // Homepage Hero
  document.getElementById("setting-hero-eyebrow").value = settings.heroEyebrow || "";
  document.getElementById("setting-hero-title").value = (settings.heroTitle || "").replace(/<br>/g, "\n").replace(/<\/?em>/g, "");
  document.getElementById("setting-hero-desc").value = settings.heroSubtitle || "";
  document.getElementById("setting-hero-note").value = (settings.heroNote || "").replace(/<\/?span>/g, "");
  document.getElementById("setting-footer-text").value = settings.footerText || "TEJASMADE. All rights reserved.";

  // Logo Preview
  if (settings.logoUrl) {
    StorageService.resolveImageSource(settings.logoUrl).then(resolved => {
      displayLogoPreview(resolved);
    });
  }

  // Admin Account Username
  document.getElementById("setting-admin-username").value = auth.username || "admin";
  document.getElementById("setting-admin-pass").value = "";
  document.getElementById("setting-admin-pass-confirm").value = "";
}

function displayLogoPreview(src) {
  const previewImg = document.getElementById("logo-preview-img");
  const wrapper = document.getElementById("logo-preview-wrapper");
  if (src && previewImg) {
    previewImg.src = src;
    wrapper.style.display = "block";
  }
}

function setupEventListeners() {
  // Logo File Upload
  const logoInput = document.getElementById("setting-logo-file");
  if (logoInput) {
    logoInput.addEventListener("change", (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      if (!file.type.match(/^image\/(png|jpeg|jpg|webp|svg\+xml)$/i)) {
        AdminUI.toast("Please select a valid image file (PNG, JPG, WEBP, SVG).", "error");
        return;
      }

      selectedLogoFile = file;
      const reader = new FileReader();
      reader.onload = (evt) => {
        pendingLogoDataUrl = evt.target.result;
        displayLogoPreview(pendingLogoDataUrl);
      };
      reader.readAsDataURL(file);
    });
  }

  // Settings Form Submit
  const form = document.getElementById("settings-form");
  if (form) {
    form.addEventListener("submit", handleSaveSettings);
  }

  // Account Form Submit
  const accountForm = document.getElementById("account-settings-form");
  if (accountForm) {
    accountForm.addEventListener("submit", handleSaveAccount);
  }

  // Export Backup Button
  const exportBtn = document.getElementById("export-backup-btn");
  if (exportBtn) {
    exportBtn.addEventListener("click", handleExportBackup);
  }

  // Import Backup File Input
  const importInput = document.getElementById("import-backup-file");
  if (importInput) {
    importInput.addEventListener("change", handleImportBackup);
  }

  // Factory Reset Button
  const resetBtn = document.getElementById("reset-defaults-btn");
  if (resetBtn) {
    resetBtn.addEventListener("click", handleResetDefaults);
  }
}

async function handleSaveSettings(e) {
  e.preventDefault();
  const saveBtn = document.getElementById("save-settings-btn");
  saveBtn.disabled = true;
  saveBtn.textContent = "Saving Settings...";

  try {
    const current = StorageService.getSettings();
    let logoUrl = current.logoUrl;

    if (selectedLogoFile) {
      const uploadResult = await StorageService.processAndSaveImageFile(selectedLogoFile, 800, 400);
      logoUrl = uploadResult.imageId;
    }

    const rawTitle = document.getElementById("setting-hero-title").value.trim();
    // Format title with line break and em for second line if multiple lines
    let formattedTitle = rawTitle;
    if (rawTitle.includes("\n")) {
      const parts = rawTitle.split("\n").filter(Boolean);
      formattedTitle = parts[0] + (parts[1] ? `<br><em>${parts[1]}</em>` : "");
    }

    const updatedSettings = {
      siteName: document.getElementById("setting-site-name").value.trim() || "TEJASMADE",
      logoUrl: logoUrl,
      announcement: document.getElementById("setting-announcement").value.trim(),
      whatsappNumber: document.getElementById("setting-whatsapp").value.trim().replace(/\D/g, ""),
      email: document.getElementById("setting-email").value.trim(),
      instagramUrl: document.getElementById("setting-instagram-url").value.trim(),
      instagramHandle: document.getElementById("setting-instagram-handle").value.trim(),
      heroEyebrow: document.getElementById("setting-hero-eyebrow").value.trim(),
      heroTitle: formattedTitle,
      heroSubtitle: document.getElementById("setting-hero-desc").value.trim(),
      heroNote: document.getElementById("setting-hero-note").value.trim(),
      footerText: document.getElementById("setting-footer-text").value.trim()
    };

    StorageService.saveSettings(updatedSettings);
    selectedLogoFile = null;

    AdminUI.toast("Website settings saved successfully. Public website updated!", "success");
  } catch (err) {
    console.error("Save settings error:", err);
    AdminUI.toast("Failed to save settings: " + (err.message || "Unknown error"), "error");
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = "Save Website Settings";
  }
}

function handleSaveAccount(e) {
  e.preventDefault();

  const usernameInput = document.getElementById("setting-admin-username");
  const newPassInput = document.getElementById("setting-admin-pass");
  const confirmPassInput = document.getElementById("setting-admin-pass-confirm");

  const username = usernameInput.value.trim();
  const newPass = newPassInput.value.trim();
  const confirmPass = confirmPassInput.value.trim();

  if (!username) {
    AdminUI.toast("Username cannot be empty.", "error");
    return;
  }

  const currentAuth = StorageService.getAuth();
  let updatedPassword = currentAuth.password;

  if (newPass) {
    if (newPass.length < 6) {
      AdminUI.toast("Password must be at least 6 characters long.", "error");
      return;
    }
    if (newPass !== confirmPass) {
      AdminUI.toast("New passwords do not match. Please verify.", "error");
      return;
    }
    updatedPassword = newPass;
  }

  StorageService.saveAuth({
    username: username,
    password: updatedPassword
  });

  newPassInput.value = "";
  confirmPassInput.value = "";

  AdminUI.toast("Admin credentials updated successfully.", "success");
}

async function handleExportBackup() {
  try {
    const jsonString = await StorageService.exportFullBackup();
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const dateStr = new Date().toISOString().split("T")[0];
    link.href = url;
    link.download = `tejasmade-backup-${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    AdminUI.toast("Full backup exported and downloaded successfully.", "success");
  } catch (err) {
    AdminUI.toast("Export failed: " + err.message, "error");
  }
}

function handleImportBackup(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (evt) => {
    try {
      const content = evt.target.result;
      const res = await StorageService.importFullBackup(content);
      if (res.success) {
        AdminUI.toast("Backup restored successfully! Reloading data...", "success");
        setTimeout(() => { window.location.reload(); }, 800);
      } else {
        AdminUI.toast("Failed to import backup: " + (res.error || "Invalid file format"), "error");
      }
    } catch (err) {
      AdminUI.toast("Import error: " + err.message, "error");
    }
  };
  reader.readAsText(file);
}

function handleResetDefaults() {
  AdminUI.confirm({
    title: "Reset Store to Default Demo Data?",
    message: "This will restore the original 12 TEJASMADE products, 6 categories, 4 hero posters, and original store settings. Any custom changes will be overwritten.",
    confirmText: "Yes, Reset Everything",
    confirmClass: "btn-danger",
    onConfirm: () => {
      StorageService.resetToDefaults();
      AdminUI.toast("Store has been reset to default demo data.", "success");
      setTimeout(() => { window.location.reload(); }, 600);
    }
  });
}
