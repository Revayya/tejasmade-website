/**
 * TEJASMADE — Central Data Storage & Persistence Service
 * Combines LocalStorage for structured metadata and IndexedDB for rich image storage.
 */

const STORAGE_KEYS = {
  PRODUCTS: "tejasmade_products_v1",
  CATEGORIES: "tejasmade_categories_v1",
  POSTERS: "tejasmade_posters_v1",
  SETTINGS: "tejasmade_settings_v1",
  AUTH: "tejasmade_auth_v1",
  CART: "tejasmade_html_cart_v1",
  LAST_UPDATE: "tejasmade_last_update"
};

// Default seed data preserving the original TEJASMADE catalogue and design
const DEFAULT_SEED_DATA = {
  settings: {
    siteName: "TEJASMADE",
    tagline: "Custom Made. Just for You.",
    logoUrl: "assets/tejasmade-logo.png",
    whatsappNumber: "919606799579",
    email: "tejasmadeofficial@gmail.com",
    instagramUrl: "https://www.instagram.com/tejasmade_official/",
    instagramHandle: "@tejasmade_official",
    announcement: "Personalized products made just for you · Bulk and corporate orders welcome",
    heroEyebrow: "YOUR IDEA. OUR CUSTOMIZATION.",
    heroTitle: "Make it personal.<br><em>Make it TEJASMADE.</em>",
    heroSubtitle: "Customized gifts, apparel and everyday products designed around your ideas. Choose a product, share your design, and order directly through WhatsApp.",
    heroNote: "<span>✓</span> Custom designs <span>✓</span> Individual & bulk orders",
    footerText: "TEJASMADE. All rights reserved.",
    status: "online"
  },
  auth: {
    username: "admin",
    password: "tejasmade123"
  },
  categories: [
    {
      id: "tshirts",
      name: "Customized T-shirts",
      label: "T-shirts",
      slug: "tshirts",
      subtitle: "Wear your idea",
      icon: "Ｔ",
      badgeColor: "cat-apparel",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=3840&q=88",
      order: 1,
      active: true
    },
    {
      id: "mugs",
      name: "Mugs & Drinkware",
      label: "Mugs & Drinkware",
      slug: "mugs",
      subtitle: "Everyday, made personal",
      icon: "☕",
      badgeColor: "cat-mugs",
      image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=3840&q=88",
      order: 2,
      active: true
    },
    {
      id: "gifts",
      name: "Corporate Gifts",
      label: "Corporate Gifts",
      slug: "gifts",
      subtitle: "Make your brand memorable",
      icon: "✦",
      badgeColor: "cat-gifts",
      image: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=3840&q=88",
      order: 3,
      active: true
    },
    {
      id: "accessories",
      name: "Keychains & Accessories",
      label: "Accessories",
      slug: "accessories",
      subtitle: "Little things, your way",
      icon: "◇",
      badgeColor: "cat-accessories",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=3840&q=88",
      order: 4,
      active: true
    },
    {
      id: "frames",
      name: "Photo Frames & Gifts",
      label: "Photo Gifts",
      slug: "frames",
      subtitle: "Keep moments close",
      icon: "▣",
      badgeColor: "cat-frames",
      image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=3840&q=88",
      order: 5,
      active: true
    },
    {
      id: "uniforms",
      name: "School Uniforms",
      label: "School Uniforms",
      slug: "uniforms",
      subtitle: "Made for your team",
      icon: "▤",
      badgeColor: "cat-uniforms",
      image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=3840&q=88",
      order: 6,
      active: true
    }
  ],
  posters: [
    {
      id: "poster_1",
      title: "Custom apparel & team uniforms",
      subtitle: "Wear your passion with premium customized fabrics and corporate uniforms.",
      offerBadge: "Popular",
      buttonText: "Explore T-shirts",
      buttonLink: "#products",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=3840&q=88",
      order: 1,
      active: true,
      createdAt: 1700000000001
    },
    {
      id: "poster_2",
      title: "Personalized mugs & drinkware",
      subtitle: "Custom printed coffee mugs, tumblers and magic cups made for everyday memories.",
      offerBadge: "Trending",
      buttonText: "View Drinkware",
      buttonLink: "#products",
      image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=3840&q=88",
      order: 2,
      active: true,
      createdAt: 1700000000002
    },
    {
      id: "poster_3",
      title: "Branded bottles for every occasion",
      subtitle: "Personalized steel bottles, sports sippers and flasks for teams and events.",
      offerBadge: "Bestseller",
      buttonText: "Order Bottles",
      buttonLink: "#products",
      image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=3840&q=88",
      order: 3,
      active: true,
      createdAt: 1700000000003
    },
    {
      id: "poster_4",
      title: "Thoughtful corporate gift collections",
      subtitle: "Executive hampers, welcome kits, and luxury custom merchandise at bulk rates.",
      offerBadge: "Corporate Special",
      buttonText: "Request Bulk Quote",
      buttonLink: "#contact",
      image: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=3840&q=88",
      order: 4,
      active: true,
      createdAt: 1700000000004
    }
  ],
  products: [
    {
      id: "tm001",
      name: "Customized T-shirt",
      category: "tshirts",
      label: "T-shirts",
      description: "Add your artwork, name, photo or company logo.",
      icon: "Ｔ",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000001
    },
    {
      id: "tm002",
      name: "Personalized Mug",
      category: "mugs",
      label: "Mugs & Drinkware",
      description: "A custom mug for gifts, events and everyday use.",
      icon: "☕",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000002
    },
    {
      id: "tm003",
      name: "Customized Bottle",
      category: "mugs",
      label: "Mugs & Drinkware",
      description: "Personalize a bottle with your design or branding.",
      icon: "♧",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000003
    },
    {
      id: "tm004",
      name: "Corporate Gift Set",
      category: "gifts",
      label: "Corporate Gifts",
      description: "Custom gift combinations for teams and businesses.",
      icon: "✦",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000004
    },
    {
      id: "tm005",
      name: "Customized Metal Pen",
      category: "gifts",
      label: "Corporate Gifts",
      description: "Personalized pens for events, teams and gifting.",
      icon: "✎",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000005
    },
    {
      id: "tm006",
      name: "Customized Keychain",
      category: "accessories",
      label: "Accessories",
      description: "Add a name, logo, photo or special design.",
      icon: "◇",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000006
    },
    {
      id: "tm007",
      name: "Mouse Pad / Desk Mat",
      category: "accessories",
      label: "Accessories",
      description: "Custom printed designs for workspaces and gifts.",
      icon: "▱",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000007
    },
    {
      id: "tm008",
      name: "Personalized Photo Frame",
      category: "frames",
      label: "Photo Gifts",
      description: "Turn a favourite photo or message into a gift.",
      icon: "▣",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000008
    },
    {
      id: "tm009",
      name: "Customized Gift Combo",
      category: "gifts",
      label: "Corporate Gifts",
      description: "Choose products for a personalized gift package.",
      icon: "🎁",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000009
    },
    {
      id: "tm010",
      name: "School Uniforms",
      category: "uniforms",
      label: "School Uniforms",
      description: "Enquire about uniform requirements and bulk orders.",
      icon: "▤",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000010
    },
    {
      id: "tm011",
      name: "Customized Desktop Gifts",
      category: "accessories",
      label: "Accessories",
      description: "Personalized items for desks, teams and events.",
      icon: "▦",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000011
    },
    {
      id: "tm012",
      name: "Custom Photo Gift",
      category: "frames",
      label: "Photo Gifts",
      description: "Share your idea for a special personalized gift.",
      icon: "♡",
      price: "",
      pricingType: "enquiry",
      image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=3840&q=88",
      active: true,
      createdAt: 1700000000012
    }
  ]
};

/**
 * IndexedDB Database for reliable, large-capacity image storage
 */
const TejasMadeImageDB = {
  dbName: "TejasMadeImageStore_v1",
  storeName: "images",
  dbInstance: null,

  async getDB() {
    if (this.dbInstance) return this.dbInstance;
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.warn("IndexedDB not supported in this browser. Falling back to LocalStorage.");
        resolve(null);
        return;
      }
      const request = indexedDB.open(this.dbName, 1);
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: "id" });
        }
      };
      request.onsuccess = (e) => {
        this.dbInstance = e.target.result;
        resolve(this.dbInstance);
      };
      request.onerror = (e) => {
        console.error("IndexedDB open error:", e);
        resolve(null);
      };
    });
  },

  async saveImage(id, dataUrl) {
    const db = await this.getDB();
    if (!db) {
      // Fallback to localStorage with a prefix if IndexedDB is unavailable
      try {
        localStorage.setItem("img_" + id, dataUrl);
      } catch (e) {
        console.warn("LocalStorage image quota exceeded:", e);
      }
      return id;
    }
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, "readwrite");
      const store = tx.objectStore(this.storeName);
      store.put({ id, dataUrl, savedAt: Date.now() });
      tx.oncomplete = () => resolve(id);
      tx.onerror = (err) => {
        console.error("IndexedDB save error:", err);
        reject(err);
      };
    });
  },

  async getImage(id) {
    if (!id) return null;
    const db = await this.getDB();
    if (!db) {
      return localStorage.getItem("img_" + id) || null;
    }
    return new Promise((resolve) => {
      const tx = db.transaction(this.storeName, "readonly");
      const store = tx.objectStore(this.storeName);
      const req = store.get(id);
      req.onsuccess = () => {
        resolve(req.result ? req.result.dataUrl : null);
      };
      req.onerror = () => {
        resolve(null);
      };
    });
  },

  async deleteImage(id) {
    if (!id) return;
    const db = await this.getDB();
    if (!db) {
      localStorage.removeItem("img_" + id);
      return;
    }
    return new Promise((resolve) => {
      const tx = db.transaction(this.storeName, "readwrite");
      const store = tx.objectStore(this.storeName);
      store.delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  },

  async getAllImages() {
    const db = await this.getDB();
    if (!db) return {};
    return new Promise((resolve) => {
      const tx = db.transaction(this.storeName, "readonly");
      const store = tx.objectStore(this.storeName);
      const req = store.getAll();
      req.onsuccess = () => {
        const map = {};
        (req.result || []).forEach(item => { map[item.id] = item.dataUrl; });
        resolve(map);
      };
      req.onerror = () => resolve({});
    });
  }
};

/**
 * Storage Service - API for all data entities
 */
const StorageService = {
  _imageCache: new Map(),

  // Initialize and seed if empty
  init() {
    if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
      this.saveProducts(DEFAULT_SEED_DATA.products);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
      this.saveCategories(DEFAULT_SEED_DATA.categories);
    }
    if (!localStorage.getItem(STORAGE_KEYS.POSTERS)) {
      this.savePosters(DEFAULT_SEED_DATA.posters);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      this.saveSettings(DEFAULT_SEED_DATA.settings);
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUTH)) {
      this.saveAuth(DEFAULT_SEED_DATA.auth);
    }
  },

  // Broadcast data update event for cross-component / cross-tab reactivity
  broadcastChange(type) {
    localStorage.setItem(STORAGE_KEYS.LAST_UPDATE, Date.now().toString());
    window.dispatchEvent(new CustomEvent("tejasmade:data_updated", { detail: { type } }));
  },

  // ---------------- PRODUCTS ----------------
  getProducts() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Error reading products:", e);
      return [];
    }
  },

  getActiveProducts(filterCategory = "all") {
    const all = this.getProducts().filter(p => p.active !== false);
    if (!filterCategory || filterCategory === "all") return all;
    return all.filter(p => p.category === filterCategory);
  },

  getProductById(id) {
    return this.getProducts().find(p => p.id === id) || null;
  },

  saveProducts(products) {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.broadcastChange("products");
  },

  upsertProduct(product) {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === product.id);
    if (index >= 0) {
      products[index] = { ...products[index], ...product, updatedAt: Date.now() };
    } else {
      products.unshift({
        ...product,
        createdAt: product.createdAt || Date.now(),
        updatedAt: Date.now()
      });
    }
    this.saveProducts(products);
    return product;
  },

  deleteProduct(id) {
    const products = this.getProducts();
    const target = products.find(p => p.id === id);
    if (target && target.imageId) {
      TejasMadeImageDB.deleteImage(target.imageId).catch(() => {});
    }
    const filtered = products.filter(p => p.id !== id);
    this.saveProducts(filtered);
    return true;
  },

  toggleProductStatus(id) {
    const products = this.getProducts();
    const product = products.find(p => p.id === id);
    if (product) {
      product.active = !product.active;
      product.updatedAt = Date.now();
      this.saveProducts(products);
      return product.active;
    }
    return false;
  },

  // ---------------- CATEGORIES ----------------
  getCategories() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      const list = data ? JSON.parse(data) : [];
      return list.sort((a, b) => (Number(a.order) || 999) - (Number(b.order) || 999));
    } catch (e) {
      console.error("Error reading categories:", e);
      return [];
    }
  },

  getActiveCategories() {
    return this.getCategories().filter(c => c.active !== false);
  },

  getCategoryById(id) {
    return this.getCategories().find(c => c.id === id || c.slug === id) || null;
  },

  saveCategories(categories) {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    this.broadcastChange("categories");
  },

  upsertCategory(category) {
    const categories = this.getCategories();
    const index = categories.findIndex(c => c.id === category.id || c.slug === category.slug);
    if (index >= 0) {
      categories[index] = { ...categories[index], ...category };
    } else {
      categories.push(category);
    }
    this.saveCategories(categories);
    return category;
  },

  deleteCategory(id) {
    const categories = this.getCategories();
    const filtered = categories.filter(c => c.id !== id && c.slug !== id);
    this.saveCategories(filtered);
    return true;
  },

  toggleCategoryStatus(id) {
    const categories = this.getCategories();
    const cat = categories.find(c => c.id === id || c.slug === id);
    if (cat) {
      cat.active = !cat.active;
      this.saveCategories(categories);
      return cat.active;
    }
    return false;
  },

  // ---------------- POSTERS / BANNERS ----------------
  getPosters() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.POSTERS);
      const list = data ? JSON.parse(data) : [];
      return list.sort((a, b) => (Number(a.order) || 999) - (Number(b.order) || 999));
    } catch (e) {
      console.error("Error reading posters:", e);
      return [];
    }
  },

  getActivePosters() {
    return this.getPosters().filter(p => p.active !== false);
  },

  getPosterById(id) {
    return this.getPosters().find(p => p.id === id) || null;
  },

  savePosters(posters) {
    localStorage.setItem(STORAGE_KEYS.POSTERS, JSON.stringify(posters));
    this.broadcastChange("posters");
  },

  upsertPoster(poster) {
    const posters = this.getPosters();
    const index = posters.findIndex(p => p.id === poster.id);
    if (index >= 0) {
      posters[index] = { ...posters[index], ...poster, updatedAt: Date.now() };
    } else {
      posters.push({
        ...poster,
        createdAt: poster.createdAt || Date.now(),
        updatedAt: Date.now()
      });
    }
    this.savePosters(posters);
    return poster;
  },

  deletePoster(id) {
    const posters = this.getPosters();
    const target = posters.find(p => p.id === id);
    if (target && target.imageId) {
      TejasMadeImageDB.deleteImage(target.imageId).catch(() => {});
    }
    const filtered = posters.filter(p => p.id !== id);
    this.savePosters(filtered);
    return true;
  },

  togglePosterStatus(id) {
    const posters = this.getPosters();
    const poster = posters.find(p => p.id === id);
    if (poster) {
      poster.active = !poster.active;
      poster.updatedAt = Date.now();
      this.savePosters(posters);
      return poster.active;
    }
    return false;
  },

  // ---------------- SETTINGS ----------------
  getSettings() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return data ? { ...DEFAULT_SEED_DATA.settings, ...JSON.parse(data) } : DEFAULT_SEED_DATA.settings;
    } catch (e) {
      return DEFAULT_SEED_DATA.settings;
    }
  },

  saveSettings(settings) {
    const merged = { ...this.getSettings(), ...settings };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(merged));
    this.broadcastChange("settings");
    return merged;
  },

  // ---------------- AUTH CREDENTIALS ----------------
  getAuth() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUTH);
      return data ? JSON.parse(data) : DEFAULT_SEED_DATA.auth;
    } catch (e) {
      return DEFAULT_SEED_DATA.auth;
    }
  },

  saveAuth(auth) {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(auth));
  },

  // ---------------- SUMMARY STATS ----------------
  getStats() {
    const products = this.getProducts();
    const categories = this.getCategories();
    const posters = this.getPosters();
    const settings = this.getSettings();

    return {
      totalProducts: products.length,
      activeProducts: products.filter(p => p.active !== false).length,
      inactiveProducts: products.filter(p => p.active === false).length,
      totalCategories: categories.length,
      activeCategories: categories.filter(c => c.active !== false).length,
      totalPosters: posters.length,
      activePosters: posters.filter(p => p.active !== false).length,
      websiteStatus: settings.status || "online",
      whatsappNumber: settings.whatsappNumber
    };
  },

  // ---------------- IMAGE HELPERS ----------------
  /**
   * Process a File from an <input type="file"> with optional downscaling to maintain high quality and performance
   */
  async processAndSaveImageFile(file, maxWidth = 1920, maxHeight = 1080) {
    return new Promise((resolve, reject) => {
      if (!file) return reject(new Error("No file selected."));
      if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
        return reject(new Error("Please upload a valid image (JPG, JPEG, PNG, or WEBP)."));
      }
      if (file.size > 8 * 1024 * 1024) {
        return reject(new Error("Image size exceeds 8MB. Please select a smaller image."));
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const rawDataUrl = e.target.result;
        // Optionally optimize image using canvas
        const img = new Image();
        img.onload = async () => {
          try {
            let width = img.width;
            let height = img.height;

            if (width > maxWidth || height > maxHeight) {
              const ratio = Math.min(maxWidth / width, maxHeight / height);
              width = Math.round(width * ratio);
              height = Math.round(height * ratio);
            }

            const canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);

            const mime = file.type === "image/png" ? "image/png" : "image/jpeg";
            const optimizedDataUrl = canvas.toDataURL(mime, 0.88);

            const imageId = "img_" + Date.now() + "_" + Math.random().toString(36).substr(2, 6);
            await TejasMadeImageDB.saveImage(imageId, optimizedDataUrl);
            StorageService._imageCache.set(imageId, optimizedDataUrl);

            resolve({
              imageId,
              dataUrl: optimizedDataUrl,
              size: file.size,
              name: file.name
            });
          } catch (canvasErr) {
            // Fallback to raw data url if canvas has issues
            const imageId = "img_" + Date.now();
            await TejasMadeImageDB.saveImage(imageId, rawDataUrl);
            StorageService._imageCache.set(imageId, rawDataUrl);
            resolve({ imageId, dataUrl: rawDataUrl });
          }
        };
        img.onerror = () => reject(new Error("Failed to load image for processing."));
        img.src = rawDataUrl;
      };
      reader.onerror = () => reject(new Error("Failed to read file from disk."));
      reader.readAsDataURL(file);
    });
  },

  /**
   * Resolve an image identifier or URL into a displayable source
   */
  async resolveImageSource(imageOrId) {
    if (!imageOrId) return "";
    if (imageOrId.startsWith("data:") || imageOrId.startsWith("http://") || imageOrId.startsWith("https://") || imageOrId.startsWith("assets/")) {
      return imageOrId;
    }
    if (this._imageCache.has(imageOrId)) {
      return this._imageCache.get(imageOrId);
    }
    const dbData = await TejasMadeImageDB.getImage(imageOrId);
    if (dbData) {
      this._imageCache.set(imageOrId, dbData);
      return dbData;
    }
    return imageOrId;
  },

  /**
   * Helper that populates all <img data-img-src="..."> elements asynchronously
   */
  hydrateDynamicImages(root = document) {
    const imgs = root.querySelectorAll("img[data-img-src], [data-bg-src]");
    imgs.forEach(async (el) => {
      const src = el.getAttribute("data-img-src");
      const bg = el.getAttribute("data-bg-src");
      if (src) {
        const resolved = await this.resolveImageSource(src);
        if (resolved) el.src = resolved;
      }
      if (bg) {
        const resolved = await this.resolveImageSource(bg);
        if (resolved) el.style.backgroundImage = `url('${resolved}')`;
      }
    });
  },

  // ---------------- BACKUP & FACTORY RESET ----------------
  async exportFullBackup() {
    const images = await TejasMadeImageDB.getAllImages();
    const backupData = {
      version: "1.0",
      exportedAt: new Date().toISOString(),
      products: this.getProducts(),
      categories: this.getCategories(),
      posters: this.getPosters(),
      settings: this.getSettings(),
      auth: this.getAuth(),
      images: images
    };
    return JSON.stringify(backupData, null, 2);
  },

  async importFullBackup(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (data.products && Array.isArray(data.products)) {
        this.saveProducts(data.products);
      }
      if (data.categories && Array.isArray(data.categories)) {
        this.saveCategories(data.categories);
      }
      if (data.posters && Array.isArray(data.posters)) {
        this.savePosters(data.posters);
      }
      if (data.settings && typeof data.settings === "object") {
        this.saveSettings(data.settings);
      }
      if (data.auth && typeof data.auth === "object") {
        this.saveAuth(data.auth);
      }
      if (data.images && typeof data.images === "object") {
        for (const [id, dataUrl] of Object.entries(data.images)) {
          await TejasMadeImageDB.saveImage(id, dataUrl);
          this._imageCache.set(id, dataUrl);
        }
      }
      this.broadcastChange("all");
      return { success: true };
    } catch (e) {
      console.error("Backup import failed:", e);
      return { success: false, error: e.message };
    }
  },

  resetToDefaults() {
    this.saveProducts(DEFAULT_SEED_DATA.products);
    this.saveCategories(DEFAULT_SEED_DATA.categories);
    this.savePosters(DEFAULT_SEED_DATA.posters);
    this.saveSettings(DEFAULT_SEED_DATA.settings);
    this.saveAuth(DEFAULT_SEED_DATA.auth);
    this.broadcastChange("all");
  }
};

// Initialize default storage immediately on script load
StorageService.init();

// Export to window
window.StorageService = StorageService;
window.TejasMadeImageDB = TejasMadeImageDB;
