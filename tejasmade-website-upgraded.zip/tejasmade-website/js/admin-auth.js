/**
 * TEJASMADE — Admin Authentication & Session Management
 * Provides client-side session checks, login, logout, and route protection.
 */

const SESSION_KEY = "tejasmade_admin_session";
const REMEMBER_KEY = "tejasmade_admin_remembered";

const AdminAuth = {
  /**
   * Check if user is currently authenticated
   */
  isAuthenticated() {
    try {
      const session = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(REMEMBER_KEY);
      if (!session) return false;
      const data = JSON.parse(session);
      return Boolean(data && data.username);
    } catch (e) {
      return false;
    }
  },

  /**
   * Get current logged-in user details
   */
  getUser() {
    try {
      const session = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(REMEMBER_KEY);
      if (!session) return null;
      return JSON.parse(session);
    } catch (e) {
      return null;
    }
  },

  /**
   * Guard admin pages — call this on protected pages
   */
  protectPage() {
    if (!this.isAuthenticated()) {
      const currentUrl = encodeURIComponent(window.location.pathname.split("/").pop() || "admin.html");
      window.location.href = `admin-login.html?redirect=${currentUrl}`;
      return false;
    }
    return true;
  },

  /**
   * Attempt login with username and password
   */
  login(username, password, remember = false) {
    const creds = window.StorageService ? window.StorageService.getAuth() : { username: "admin", password: "tejasmade123" };
    
    const cleanUser = String(username || "").trim();
    const cleanPass = String(password || "").trim();

    if (!cleanUser || !cleanPass) {
      return { success: false, message: "Please provide both username and password." };
    }

    if (cleanUser === creds.username && cleanPass === creds.password) {
      const sessionData = {
        username: cleanUser,
        role: "Store Administrator",
        loginTime: Date.now()
      };
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
      if (remember) {
        localStorage.setItem(REMEMBER_KEY, JSON.stringify(sessionData));
      } else {
        localStorage.removeItem(REMEMBER_KEY);
      }
      return { success: true };
    }

    return { success: false, message: "Invalid username or password. Please verify your credentials." };
  },

  /**
   * Log out and redirect
   */
  logout() {
    sessionStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(REMEMBER_KEY);
    window.location.href = "admin-login.html";
  }
};

window.AdminAuth = AdminAuth;
