/**
 * TEJASMADE — Admin Panel Common UI Utilities
 * Sidebar toggles, toast notifications, confirmation dialogs, and image pickers
 */

const AdminUI = {
  init() {
    this.setupMobileSidebar();
    this.setupUserBadge();
    this.setupToastContainer();
    this.setupGlobalConfirmModal();
  },

  setupMobileSidebar() {
    const sidebar = document.getElementById("admin-sidebar");
    const backdrop = document.getElementById("sidebar-backdrop");
    const openBtn = document.getElementById("mobile-menu-toggle");
    const closeBtn = document.getElementById("sidebar-close-btn");

    if (openBtn && sidebar) {
      openBtn.addEventListener("click", () => {
        sidebar.classList.add("open");
        if (backdrop) backdrop.classList.add("active");
      });
    }

    const closeSidebar = () => {
      if (sidebar) sidebar.classList.remove("open");
      if (backdrop) backdrop.classList.remove("active");
    };

    if (closeBtn) closeBtn.addEventListener("click", closeSidebar);
    if (backdrop) backdrop.addEventListener("click", closeSidebar);
  },

  setupUserBadge() {
    const user = window.AdminAuth ? window.AdminAuth.getUser() : null;
    const nameEls = document.querySelectorAll(".admin-username-display");
    const avatarEls = document.querySelectorAll(".admin-avatar-char");

    if (user && user.username) {
      nameEls.forEach(el => { el.textContent = user.username; });
      avatarEls.forEach(el => { el.textContent = user.username.charAt(0).toUpperCase(); });
    }
  },

  setupToastContainer() {
    if (!document.getElementById("toast-container")) {
      const container = document.createElement("div");
      container.id = "toast-container";
      container.className = "toast-container";
      document.body.appendChild(container);
    }
  },

  toast(message, type = "success", title = "") {
    this.setupToastContainer();
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;

    let iconChar = "✓";
    let defaultTitle = "Success";
    if (type === "error") {
      iconChar = "✕";
      defaultTitle = "Error";
    } else if (type === "warning") {
      iconChar = "!";
      defaultTitle = "Notice";
    }

    toast.innerHTML = `
      <div class="toast-icon">${iconChar}</div>
      <div class="toast-content">
        <div class="toast-title">${title || defaultTitle}</div>
        <div class="toast-message">${message}</div>
      </div>
      <button type="button" class="toast-close" aria-label="Close notification">×</button>
    `;

    const closeBtn = toast.querySelector(".toast-close");
    closeBtn.addEventListener("click", () => {
      toast.classList.add("toast-hiding");
      setTimeout(() => toast.remove(), 250);
    });

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentNode) {
        toast.classList.add("toast-hiding");
        setTimeout(() => toast.remove(), 250);
      }
    }, 4500);
  },

  setupGlobalConfirmModal() {
    if (document.getElementById("admin-confirm-modal")) return;

    const modal = document.createElement("div");
    modal.id = "admin-confirm-modal";
    modal.className = "modal-overlay";
    modal.innerHTML = `
      <div class="modal-dialog modal-sm">
        <div class="modal-header">
          <h3 id="confirm-modal-title">Confirm Action</h3>
          <button type="button" class="modal-close-btn" id="confirm-modal-close">×</button>
        </div>
        <div class="modal-body">
          <p id="confirm-modal-message" style="margin: 0; font-size: 13.5px; color: var(--ink-secondary); line-height: 1.6;"></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="confirm-modal-cancel">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirm-modal-proceed">Delete</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const close = () => modal.classList.remove("active");
    modal.querySelector("#confirm-modal-close").addEventListener("click", close);
    modal.querySelector("#confirm-modal-cancel").addEventListener("click", close);
  },

  confirm({ title = "Are you sure?", message = "This action cannot be undone.", confirmText = "Confirm", confirmClass = "btn-danger", onConfirm }) {
    this.setupGlobalConfirmModal();
    const modal = document.getElementById("admin-confirm-modal");
    if (!modal) return;

    document.getElementById("confirm-modal-title").textContent = title;
    document.getElementById("confirm-modal-message").innerHTML = message;
    
    const proceedBtn = document.getElementById("confirm-modal-proceed");
    proceedBtn.textContent = confirmText;
    proceedBtn.className = `btn ${confirmClass}`;

    // Remove previous listeners
    const newProceedBtn = proceedBtn.cloneNode(true);
    proceedBtn.parentNode.replaceChild(newProceedBtn, proceedBtn);

    newProceedBtn.addEventListener("click", () => {
      modal.classList.remove("active");
      if (typeof onConfirm === "function") {
        onConfirm();
      }
    });

    modal.classList.add("active");
  }
};

document.addEventListener("DOMContentLoaded", () => {
  AdminUI.init();
});

window.AdminUI = AdminUI;
