# TEJASMADE Website & Admin Control Panel Integration

> **Customized Gifts, Apparel, Corporate Merchandise & Store CMS**  
> An upgraded, professional e-commerce storefront with an embedded Admin Control Panel built strictly with vanilla HTML5, CSS3, JavaScript, LocalStorage, and IndexedDB.

---

## 📋 Table of Contents
1. [Overview & Highlights](#-overview--highlights)
2. [Technology Stack](#-technology-stack)
3. [Project Structure](#-project-structure)
4. [Admin Control Panel Features](#-admin-control-panel-features)
5. [Public Website Integration](#-public-website-integration)
6. [Image Storage Architecture & Limitations](#-image-storage-architecture--limitations)
7. [Admin Credentials & Setup](#-admin-credentials--setup)
8. [Functional Testing Checklist](#-functional-testing-checklist)

---

## 🌟 Overview & Highlights

This release upgrades the **TEJASMADE** storefront with a full-featured, responsive **Admin Control Panel (CMS)**.

- **Preserved Brand Identity:** Retains the exact TEJASMADE palette (cream `#f7f6f1`, ink `#20211e`, forest green `#1b6b48`, and gold `#c6a46a`), typography (`DM Sans` & `Manrope`), official logo assets, and layout structure.
- **Frontend-Only Architecture:** Requires no external backend, Node.js server, PHP runtime, or cloud database. Runs natively in any modern browser.
- **Dynamic Content Engine:** The storefront hero carousel, product catalog, category grid, filter bars, announcement banner, and contact routing dynamically synchronize with the Admin Panel in real time.
- **WhatsApp Direct Ordering:** Preserves and enhances the checkout workflow, formatting enquiries with item details, quantities, prices, and customer customization notes directed to the admin-configured WhatsApp number.

---

## 🛠 Technology Stack

- **Markup & Layout:** Semantic HTML5 & Responsive Mobile-First Grid/Flexbox
- **Styling:** Modular CSS3 with custom variables, smooth transitions, and backdrop filters
- **Logic:** Modern Vanilla JavaScript (ES6+), zero frameworks or third-party dependencies
- **Data Persistence:** LocalStorage (structured JSON entities) + IndexedDB (large image storage)
- **Image Processing:** Browser File API & HTML5 Canvas optimization (max 1920px bounds)

---

## 📁 Project Structure

```
tejasmade-website/
│
├── index.html                  # Public storefront (hero slider, categories, dynamic products)
├── cart.html                   # Shopping cart & WhatsApp checkout enquiry
├── admin-login.html            # Protected admin login interface with show/hide password
├── admin.html                  # Admin Dashboard (KPI metrics, recent updates, quick actions)
├── admin-products.html         # Product Management (add, edit, delete, upload image, pricing)
├── admin-posters.html          # Poster Management (hero banners, promotional offers, slides)
├── admin-categories.html       # Category Management (categories, images, icons, ordering)
├── admin-settings.html         # Store Settings (logo, WhatsApp number, copy, credentials, backup)
│
├── css/
│   ├── style.css               # Storefront & cart styling with brand palette
│   └── admin.css               # Professional CMS dashboard styling
│
├── js/
│   ├── storage.js              # Central persistence layer (LocalStorage + IndexedDB engine)
│   ├── admin-auth.js           # Session authentication, login/logout, page route protection
│   ├── admin-common.js         # Shared admin UI components (toasts, confirm modals, drawer)
│   ├── admin-dashboard.js      # Dashboard KPI cards and activity controller
│   ├── admin-products.js       # Product catalogue CRUD controller & image processor
│   ├── admin-posters.js        # Promotional poster/banner controller
│   ├── admin-categories.js     # Category management controller
│   ├── admin-settings.js       # Website settings & JSON backup import/export
│   └── script.js               # Dynamic storefront controller & WhatsApp order generator
│
├── assets/
│   ├── tejasmade-logo.png      # TEJASMADE brand logo
│   ├── TejasMadeLogo.png       # High-resolution original logo asset
│   └── images/                 # Local image directory for assets
│
├── README.txt                  # Documentation & setup instructions (plain text)
└── README.md                   # Formatted Markdown documentation
```

---

## 🎛 Admin Control Panel Features

### 1. Authentication & Route Guard (`admin-login.html`)
- Pre-configured demo credentials:
  - **Username:** `admin`
  - **Password:** `tejasmade123`
- One-click **"Auto-fill Demo Credentials"** button for quick evaluation.
- Show/Hide password toggle.
- Session protection on all admin pages (unauthenticated visits automatically redirect to `admin-login.html`).

### 2. Admin Dashboard (`admin.html`)
- 5 live KPI metric cards: **Total Products**, **Active Products**, **Total Categories**, **Active Posters**, and **Storage Engine Status**.
- Quick Action buttons for fast navigation.
- Recent products overview table with image thumbnails and instant editing links.
- Recent promotional banners visual cards.
- Mobile off-canvas hamburger navigation drawer.

### 3. Product Management (`admin-products.html`)
- **Add & Edit:** Configure Product Name, ID, Category, Description, Pricing, and Visibility.
- **Dual Pricing Mode:** Supports either *"Enquiry Only (Price on WhatsApp)"* or *"Fixed Display Price"*.
- **Image Upload:** Upload JPG, JPEG, PNG, or WEBP from disk with live preview, replacement, and removal.
- **Status Toggle:** Quick toggle switch to instantly activate or deactivate products on the storefront.
- **Instant Search & Category Filter:** Live search by title, ID, or description.
- **Safe Deletion:** Modal confirmation preventing accidental data loss.

### 4. Poster & Banner Management (`admin-posters.html`)
- Upload promotional hero banners from computer.
- Add banner title, subtitle, promotional badge (e.g. *"20% Off"*, *"Bestseller"*), CTA button text, and link destination.
- Set numeric display order.
- Active posters automatically power the storefront's responsive hero carousel.

### 5. Category Management (`admin-categories.html`)
- Add, edit, and delete product categories with image upload and icon/symbol customization.
- Category changes immediately reflect in storefront category cards and filter pills.

### 6. Store Settings (`admin-settings.html`)
- Modify store name, upload new brand logo, and update announcement bar text.
- Customize homepage hero heading (multiline support with brand accent), description, and trust notes.
- Configure WhatsApp contact phone number (used for all cart checkout enquiries).
- Update official email, Instagram handle, and footer copyright text.
- Change admin username and password.
- **One-Click Backup & Restore:** Export all products, categories, posters, settings, and IndexedDB images into a single transferable JSON file.

---

## 🛒 Public Website Integration

- **Zero Hardcoded Products:** The static array in `script.js` has been replaced with dynamic fetching from `StorageService`.
- **Cart Continuity:** Shopping cart items, counts, and quantities persist in `localStorage` across page views and product edits.
- **WhatsApp Enquiry Generator:** The order button formats an enquiry including customer name, city, selected items (with quantities & prices), and custom notes, opening directly in WhatsApp.
- **Cross-Tab Reactivity:** When changes are saved in the Admin Control Panel, public storefront tabs update immediately.

---

## 💾 Image Storage Architecture & Limitations

### Why LocalStorage + IndexedDB Hybrid?
1. **LocalStorage Quota (~5MB):** Standard `localStorage` is ideal for lightweight JSON metadata, but storing multiple high-resolution Base64 images quickly exceeds browser storage quotas (`QuotaExceededError`).
2. **IndexedDB Integration:** Our hybrid persistence engine (`js/storage.js`) automatically delegates uploaded images to **IndexedDB (`TejasMadeImageStore_v1`)**, allowing hundreds of megabytes of image storage.
3. **Canvas Downscaling:** Uploaded images are resized to a maximum of 1920×1080px via an off-screen HTML5 canvas, ensuring optimal file size and fast render times.

### Browser Environment Notes
- Data is stored locally within the browser origin. Clearing browser cache or site data will wipe the local store unless a JSON backup has been saved.
- For production multi-user environments with server-side inventory and database persistence, integrate a secure backend (Node.js, Python, PHP) with HTTPS and cookie sessions.

---

## 🚀 How to Run

### Direct File Execution
Double-click `index.html` to view the storefront, or `admin-login.html` to access the Admin Panel.

### Local Web Server (Recommended)
Using Python:
```bash
python -m http.server 8000
```
Then visit: `http://localhost:8000`

---

## 🏆 Testing Checklist Completed
- [x] Admin login with demo credentials (`admin` / `tejasmade123`)
- [x] Admin logout and route protection redirect
- [x] Add new product with image and verify on homepage
- [x] Edit product details and verify updates
- [x] Delete product with confirmation modal
- [x] Upload product image from computer with live preview
- [x] Add promotional poster and verify display on hero carousel
- [x] Edit and delete promotional posters
- [x] Add, edit, and delete categories
- [x] Change WhatsApp number in settings and verify checkout link
- [x] Add items to cart, modify quantities, and remove items
- [x] Generate formatted WhatsApp order enquiry
- [x] Refresh browser and verify data persistence
- [x] Test responsive layouts on mobile and desktop viewports
